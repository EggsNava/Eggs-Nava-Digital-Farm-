# Security Specification — EGGS NAVA DIGITAL FARM

## 1. Data Invariants

1. **PII Isolation & User Account Integrity**:
   - `users/{userId}` contains PII (`phone`, `email`) and financial balances (`availableBalance`, `eggsBalance`, `activeHens`, etc.).
   - Only the account owner (`request.auth.uid == userId`) or an authorized Admin (`isAdmin()`) can `get` or `list` from `/users/{userId}`.
   - Normal users creating their `/users/{userId}` document MUST initialize `role == 'user'`, `availableBalance == 0`, `eggsBalance == 0`, `activeHens == 0`, `totalHens == 0`, `totalEggsProfit == 0`, `referralBonus == 0`, `totalInvestment == 0`, `totalWithdraw == 0`.
   - Normal users updating `/users/{userId}` can ONLY update non-financial profile fields (`phone`, `updatedAt`) or harvest state (`eggsBalance`, `totalEggsProfit`, `lastHarvestAt`) via strict action gates, while Admin can update all fields.
2. **Public Profile Separation**:
   - `users_public/{userId}` stores only non-PII (`uid`, `username`, `referralCode`, `referredBy`, `verifiedFarmer`, `status`, `createdAt`) so referral lookup and team member displays never expose phone numbers or emails.
3. **Admin-Controlled Catalog & Settings**:
   - `/plans/{planId}`, `/buyers/{buyerId}`, and `/settings/{settingId}` are readable by the public/authenticated users so the homepage and dashboard always display live Admin-configured values, but ONLY `isAdmin()` can create, update, or delete them.
4. **Pending-Only Financial Requests**:
   - When a normal user creates a document in `/deposits/{depositId}`, `/hen_orders/{orderId}`, `/egg_sales/{saleId}`, or `/withdrawals/{withdrawalId}`, `status` MUST be `'Pending'`, and `userId` MUST equal `request.auth.uid`.
   - Normal users can NEVER approve or reject their own requests or modify financial request amounts after creation. Only `isAdmin()` can transition `status` to `'Approved'` or `'Rejected'`.
5. **Audit Trail & Ledger Protection**:
   - `/audit_logs/{logId}` is strictly readable and writable ONLY by `isAdmin()`.
   - `/transactions/{txId}` is readable only by the transaction owner (`resource.data.userId == request.auth.uid`) or `isAdmin()`.

## 2. The "Dirty Dozen" Payloads

1. **Self-Assigned Admin Role on Signup**:
   `{ "uid": "user1", "username": "farmer1", "role": "admin", "availableBalance": 0, ... }` -> Rejected (`role == 'user'` required for non-admins).
2. **Pre-Loaded Balance on Signup**:
   `{ "uid": "user1", "username": "farmer1", "role": "user", "availableBalance": 500000, ... }` -> Rejected (`availableBalance == 0` required on create).
3. **Shadow Field Injection on Deposit**:
   `{ "id": "dep1", "userId": "user1", "amount": 1000, "status": "Pending", "isVerifiedBySystem": true }` -> Rejected (`hasOnly` key guard).
4. **Pre-Approved Deposit Creation by User**:
   `{ "id": "dep1", "userId": "user1", "amount": 5000, "status": "Approved", ... }` -> Rejected (`status == 'Pending'` required on create).
5. **User Self-Approving Pending Withdrawal**:
   `update /withdrawals/w1 { "status": "Approved" }` by `user1` -> Rejected (only `isAdmin()` can update withdrawal status).
6. **Unauthenticated or Non-Owner PII Scrape**:
   `get /users/victimUser` by `attackerUser` -> Rejected (`isOwner(userId) || isAdmin()` required).
7. **Blanket User List Scraping**:
   `list /users` by `attackerUser` without `where('uid', '==', request.auth.uid)` -> Rejected (`resource.data.uid == request.auth.uid || isAdmin()`).
8. **Customer Modifying Plan Price**:
   `update /plans/golden_hen { "henPrice": 1 }` by `user1` -> Rejected (`isAdmin()` required).
9. **Customer Modifying Payment Gateway Numbers**:
   `update /settings/global { "jazzCashNumber": "03009999999" }` by `user1` -> Rejected (`isAdmin()` required).
10. **Identity Spoofing on Hen Order**:
    `create /hen_orders/ord1 { "userId": "otherUser", "status": "Pending", ... }` by `user1` -> Rejected (`incoming().userId == request.auth.uid`).
11. **Oversized String DoW Attack**:
    `create /deposits/dep1 { "proofNote": "<2000 char string>" }` -> Rejected (`proofNote.size() <= 500`).
12. **Unverified Admin Email Spoof**:
    Request with `request.auth.token.email == 'inam3nd9980@gmail.com'` and `email_verified == false` -> Rejected (`request.auth.token.email_verified == true` required).
