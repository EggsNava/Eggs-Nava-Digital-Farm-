# EGGS NAVA DIGITAL FARM

**Growing healthy hens, naturally.**

A complete, production-ready digital poultry farming platform built with **React 19**, **TypeScript**, **Tailwind CSS v4**, **Vite**, **Firebase Authentication**, and **Cloud Firestore**.

Repository: `EggsNava/Eggs-Nava-Digital-Farm-`

---

## Project Folder Structure

```text
Eggs-Nava-Digital-Farm-/
├── .env.example                  # Environment variable template
├── .gitignore                    # Git ignore rules
├── eslint.config.js              # ESLint configuration for Firestore security rules
├── firebase-applet-config.json   # Firebase project & Firestore database configuration
├── firebase-blueprint.json       # Firestore entity & collection schema blueprint
├── firebase.json                 # Firebase CLI configuration pointing to firestore.rules
├── firestore.rules               # Hardened Cloud Firestore security rules
├── index.html                    # Main HTML entry point
├── metadata.json                 # Application metadata
├── package.json                  # Project dependencies and build scripts
├── README.md                     # Project documentation and deployment guide
├── security_spec.md              # Firestore security specification & invariants
├── tsconfig.json                 # TypeScript configuration
├── vite.config.ts                # Vite bundler configuration
└── src/
    ├── App.tsx                   # Root application state, Firebase listeners, and routing
    ├── firebase.ts               # Firebase Auth & Firestore SDK initialization
    ├── index.css                 # Tailwind CSS & typography rules
    ├── main.tsx                  # React DOM root mount
    ├── types.ts                  # TypeScript interfaces and initial platform defaults
    ├── assets/
    │   └── images/               # Realistic brown hen, eggs, and pasture photographs
    ├── components/
    │   ├── AdminPanel.tsx        # Owner/Admin Panel (Plans, Users, Balances, Approvals, Settings)
    │   ├── AuthPages.tsx         # Registration, Login, and Urdu/English Welcome Page
    │   ├── EggMarket.tsx         # Egg Rapid wholesale buyer marketplace
    │   ├── FarmMarket.tsx        # 3-step hen package purchase flow
    │   ├── HomePage.tsx          # Public landing page with live Firebase packages
    │   └── UserDashboard.tsx     # Farmer dashboard, daily harvest timer, deposits, withdrawals, team
    └── constants/
        └── assets.ts             # Image asset path mappings
```

---

## Local Development & Build

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server (Port 3000):**
   ```bash
   npm run dev
   ```

3. **Type-check & Lint Firestore Rules:**
   ```bash
   npm run lint
   npx eslint firestore.rules
   ```

4. **Build for production:**
   ```bash
   npm run build
   ```

---

## Pushing to GitHub (`EggsNava/Eggs-Nava-Digital-Farm-`)

You can export directly using the **Export to GitHub** button in Google AI Studio, or via Git CLI:

```bash
git init
git branch -M main
git add .
git commit -m "Initial commit: EGGS NAVA DIGITAL FARM complete platform"
git remote add origin https://github.com/EggsNava/Eggs-Nava-Digital-Farm-.git
git push -u origin main
```
