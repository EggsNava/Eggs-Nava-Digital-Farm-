export const FARM_IMAGES = {
  hero: '/src/assets/images/hero_poultry_farm_1791240568295.jpg',
  hen: '/src/assets/images/golden_brown_hen_1791240579295.jpg',
  eggs: '/src/assets/images/farm_fresh_eggs_1791240589381.jpg',
  pasture: '/src/assets/images/modern_poultry_pasture_1791240598553.jpg',
} as const;

export function getPlanImage(imageKey?: string): string {
  if (imageKey === 'eggs') return FARM_IMAGES.eggs;
  if (imageKey === 'pasture') return FARM_IMAGES.pasture;
  if (imageKey === 'hero') return FARM_IMAGES.hero;
  return FARM_IMAGES.hen;
}
