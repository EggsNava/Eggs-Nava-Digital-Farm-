import React from 'react';
import { ArrowRight, MessageCircle, Radio } from 'lucide-react';
import { FarmPlan, PlatformSettings } from '../types';
import { FARM_IMAGES, getPlanImage } from '../constants/assets';

interface HomePageProps {
  onNavigate: (mode: 'home' | 'login' | 'register' | 'welcome' | 'dashboard' | 'admin') => void;
  plans: FarmPlan[];
  settings: PlatformSettings;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  plans,
  settings,
  isAuthenticated,
  isAdmin,
}) => {
  const activePlans = plans.filter((p) => p.active);

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-stone-900 flex flex-col">
      {/* Top Bar Contract: 3 Zones (Brand title | 4-6 nav links | 1-2 primary actions) */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-stone-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Zone 1: Brand Title */}
          <a
            href="#top"
            className="text-lg font-bold tracking-tight text-stone-900 font-display whitespace-nowrap"
          >
            EGGS NAVA DIGITAL FARM
          </a>

          {/* Zone 2: 4-5 Clean Text Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-600">
            <a href="#care" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              Humane Care
            </a>
            <a href="#packages" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              Farm Packages
            </a>
            <a href="#routines" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              Smarter Farming
            </a>
            <a href="#community" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              Community
            </a>
          </nav>

          {/* Zone 3: 1-2 Primary Actions */}
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                {isAdmin && (
                  <button
                    onClick={() => onNavigate('admin')}
                    className="px-4 py-2 text-xs font-semibold text-stone-800 border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Admin Panel
                  </button>
                )}
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="px-4 py-2 text-xs font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Open Dashboard
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => onNavigate('login')}
                  className="px-4 py-2 text-xs font-semibold text-stone-800 border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Login
                </button>
                <button
                  onClick={() => onNavigate('register')}
                  className="px-4 py-2 text-xs font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Register
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-6 py-12 md:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-6">
              <div className="flex items-center gap-2 text-xs font-medium text-amber-800">
                <span>Naturally raised</span>
                <span aria-hidden="true">·</span>
                <span>Farm-fresh quality</span>
                <span aria-hidden="true">·</span>
                <span>Fresh daily</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-bold text-stone-900 leading-[1.08] tracking-tight text-balance">
                Growing healthy hens, naturally.
              </h1>

              <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl">
                EGGS NAVA DIGITAL FARM connects modern poultry farmers with naturally raised brown laying hens, transparent daily egg harvests, and direct wholesale egg buyers. Build a thriving flock with clean routines and dependable daily harvest tracking.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'register')}
                  className="px-6 py-3.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-sm flex items-center gap-2.5 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>Join the community</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'login')}
                  className="px-6 py-3.5 rounded-xl border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 font-semibold text-sm transition-colors whitespace-nowrap cursor-pointer"
                >
                  {isAuthenticated ? 'Go to My Farm' : 'Farmer Login'}
                </button>
              </div>

              {/* Admin-Controlled Platform Information / Farmer Community Statistics */}
              <div className="pt-6 border-t border-stone-200 grid grid-cols-3 gap-6">
                <div>
                  <p className="text-xs text-stone-500 mb-1">Active Farm Packages</p>
                  <p className="text-xl font-bold text-stone-900 font-mono tabular-nums">
                    {activePlans.length} {activePlans.length === 1 ? 'Plan' : 'Plans'}
                  </p>
                  <p className="text-xs text-stone-500 mt-0.5">Live from Firebase</p>
                </div>
                <div>
                  <p className="text-xs text-stone-500 mb-1">Starting Hen Price</p>
                  <p className="text-xl font-bold text-amber-800 font-mono tabular-nums">
                    PKR {activePlans.length > 0 ? Math.min(...activePlans.map((p) => p.henPrice)) : 500}
                  </p>
                  <p className="text-xs text-stone-500 mt-0.5">Per laying hen</p>
                </div>
                <div>
                  <p className="text-xs text-stone-500 mb-1">Harvest Cycle</p>
                  <p className="text-base font-bold text-emerald-800 font-mono tabular-nums">
                    {settings.dailyHarvestRateInfo || '24-Hour Cycle'}
                  </p>
                  <p className="text-xs text-stone-500 mt-0.5">{settings.communityFarmersCount}</p>
                </div>
              </div>
            </div>

            {/* Right Hero Photograph */}
            <div className="lg:col-span-6">
              <div className="relative rounded-2xl overflow-hidden border border-stone-200 bg-stone-900 aspect-16/9 shadow-sm">
                <img
                  src={FARM_IMAGES.hero}
                  alt="Real brown hens grazing on lush green grass at EGGS NAVA DIGITAL FARM"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent flex flex-col justify-end p-6">
                  <div className="flex items-center justify-between text-white">
                    <div>
                      <p className="text-xs text-amber-300 font-medium">
                        Humane care · Healthy flock · Farm thriving
                      </p>
                      <p className="text-lg font-semibold mt-0.5">
                        Healthy hens make a healthy farm
                      </p>
                    </div>
                    <span className="text-xs font-mono text-stone-200">
                      Pasture-Raised Brown Layers
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Core Pillars Section: Humane care, Healthy flock, Farm thriving */}
        <section id="care" className="bg-white border-y border-stone-200 py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-2xl mb-12">
              <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-2">
                Natural Poultry Standards
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight text-balance">
                Healthy hens make a healthy farm
              </h2>
              <p className="text-base text-stone-600 mt-3 leading-relaxed">
                Our digital farming ecosystem is built around real agricultural principles: open pasture environments, balanced organic grain nutrition, and stress-free daily egg collection.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Card 1 */}
              <div className="border border-stone-200 rounded-2xl overflow-hidden bg-[#F9F8F6] flex flex-col">
                <div className="aspect-4/3 bg-stone-200 overflow-hidden">
                  <img
                    src={FARM_IMAGES.hen}
                    alt="Close-up of healthy brown laying hen"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-stone-500 mb-2">
                      <span>01. Humane care</span>
                      <span aria-hidden="true">·</span>
                      <span>Naturally raised</span>
                    </div>
                    <h3 className="text-xl font-bold text-stone-900 mb-2">
                      Healthy flock & pasture nutrition
                    </h3>
                    <p className="text-sm text-stone-600 leading-relaxed">
                      Every brown laying hen is raised in clean, sunlit pasture surroundings with natural forage, clean water, and attentive veterinary oversight.
                    </p>
                  </div>
                </div>
              </div>

              {/* Card 2 */}
              <div className="border border-stone-200 rounded-2xl overflow-hidden bg-[#F9F8F6] flex flex-col">
                <div className="aspect-4/3 bg-stone-200 overflow-hidden">
                  <img
                    src={FARM_IMAGES.eggs}
                    alt="Basket of farm-fresh brown eggs"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-stone-500 mb-2">
                      <span>02. Farm-fresh quality</span>
                      <span aria-hidden="true">·</span>
                      <span>Fresh daily</span>
                    </div>
                    <h3 className="text-xl font-bold text-stone-900 mb-2">
                      Consistent daily egg harvest
                    </h3>
                    <p className="text-sm text-stone-600 leading-relaxed">
                      Track your active flock’s daily egg production in real time and sell harvested eggs directly in the Egg Rapid market at transparent buyer rates.
                    </p>
                  </div>
                </div>
              </div>

              {/* Card 3 */}
              <div className="border border-stone-200 rounded-2xl overflow-hidden bg-[#F9F8F6] flex flex-col">
                <div className="aspect-4/3 bg-stone-200 overflow-hidden">
                  <img
                    src={FARM_IMAGES.pasture}
                    alt="Free-range poultry farm pasture"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-stone-500 mb-2">
                      <span>03. Smarter farming</span>
                      <span aria-hidden="true">·</span>
                      <span>Farm thriving</span>
                    </div>
                    <h3 className="text-xl font-bold text-stone-900 mb-2">
                      Healthier and cleaner farm routines
                    </h3>
                    <p className="text-sm text-stone-600 leading-relaxed">
                      Easy poultry-care guidance, structured 24-hour harvest timers, and a supportive farmer community help your digital farm thrive sustainably.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Live Farm Market Packages (Synced from Firebase Firestore) */}
        <section id="packages" className="py-16 max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider mb-2">
                EGGS NAVA DIGITAL FARM MARKET
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
                Live Hen Farming Packages
              </h2>
              <p className="text-sm text-stone-600 mt-2 max-w-xl">
                All package prices, daily egg yields, referral rewards, and cycle durations are read directly from Firebase and managed by the platform Admin.
              </p>
            </div>
            <button
              onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'register')}
              className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold transition-colors whitespace-nowrap self-start md:self-auto cursor-pointer"
            >
              Start Your Flock Today
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {activePlans.map((plan) => (
              <div
                key={plan.id}
                className="bg-white border border-stone-200 rounded-2xl overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-4/3 bg-stone-100 relative overflow-hidden">
                    <img
                      src={getPlanImage(plan.imageKey)}
                      alt={plan.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <h3 className="text-xl font-bold text-stone-900">{plan.name}</h3>
                      <span className="text-sm font-bold text-amber-800 font-mono tabular-nums">
                        PKR {plan.henPrice.toLocaleString()} / hen
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 leading-relaxed mb-5">
                      {plan.description}
                    </p>

                    <div className="border-t border-stone-200 pt-4 space-y-2.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-stone-500">Hen Price</span>
                        <span className="font-semibold text-stone-900 font-mono tabular-nums">
                          PKR {plan.henPrice.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-stone-500">Daily Eggs</span>
                        <span className="font-semibold text-emerald-800 font-mono tabular-nums">
                          {plan.dailyEggs} {plan.dailyEggs === 1 ? 'Egg' : 'Eggs'} / day
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-stone-500">Refer Reward</span>
                        <span className="font-semibold text-stone-900 font-mono tabular-nums">
                          PKR {plan.referReward.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-stone-500">Plan Duration</span>
                        <span className="font-semibold text-stone-900 font-mono tabular-nums">
                          {plan.durationDays} Days
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-6 pb-6">
                  <button
                    onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'register')}
                    className="w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Select {plan.name}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Smarter Farming & Supportive Community */}
        <section id="routines" className="bg-white border-t border-stone-200 py-16">
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-6">
              <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                Smarter Farming & Community Care
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight text-balance">
                Easy poultry-care guidance & supportive farmer community
              </h2>
              <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
                Whether you are starting with a single Golden Hen or scaling a full pasture flock, EGGS NAVA DIGITAL FARM provides structured daily harvest timers, direct wholesale egg buyers, and responsive community support via WhatsApp.
              </p>

              <div className="space-y-4 pt-2">
                <div className="border-l-2 border-amber-700 pl-4">
                  <h3 className="text-sm font-bold text-stone-900">
                    01. Easy poultry-care guidance
                  </h3>
                  <p className="text-xs text-stone-600 mt-1">
                    Clear 3-step hen package selection, transparent order summaries, and automated 24-hour egg collection schedules.
                  </p>
                </div>
                <div className="border-l-2 border-emerald-700 pl-4">
                  <h3 className="text-sm font-bold text-stone-900">
                    02. Healthier and cleaner farm routines
                  </h3>
                  <p className="text-xs text-stone-600 mt-1">
                    Every deposit, hen purchase, egg sale, and withdrawal is verified and recorded in your personal Firebase ledger.
                  </p>
                </div>
                <div className="border-l-2 border-stone-800 pl-4">
                  <h3 className="text-sm font-bold text-stone-900">
                    03. Supportive farmer community
                  </h3>
                  <p className="text-xs text-stone-600 mt-1">
                    Connect with fellow farmers, share your referral code, and receive instant market updates on our WhatsApp Group and Channel.
                  </p>
                </div>
              </div>

              <div id="community" className="pt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'register')}
                  className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs transition-colors whitespace-nowrap cursor-pointer"
                >
                  Join the community
                </button>
                <a
                  href={settings.whatsappAdmin || 'https://wa.me/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-3 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 font-semibold text-xs flex items-center gap-2 transition-colors whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-700" />
                  <span>WhatsApp Admin</span>
                </a>
                <a
                  href={settings.whatsappChannel || 'https://whatsapp.com/channel/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-3 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 font-semibold text-xs flex items-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Radio className="w-4 h-4 text-amber-700" />
                  <span>WhatsApp Channel</span>
                </a>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="rounded-2xl overflow-hidden border border-stone-200 bg-stone-900 aspect-16/9">
                <img
                  src={FARM_IMAGES.pasture}
                  alt="Brown hens roaming on clean green pasture"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Professional Footer */}
      <footer className="bg-stone-900 text-stone-300 border-t border-stone-800 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div>
            <p className="text-lg font-bold text-white font-display tracking-tight">
              EGGS NAVA DIGITAL FARM
            </p>
            <p className="text-xs text-stone-400 mt-1 max-w-md">
              Growing healthy hens, naturally. Professional digital poultry management, daily harvest tracking, and verified egg market trading.
            </p>
            {settings.fbrSecpEnabled && (settings.fbrRegistrationInfo || settings.secpRegistrationInfo) && (
              <p className="text-xs text-emerald-400 mt-2 font-mono">
                {settings.fbrRegistrationInfo} {settings.secpRegistrationInfo ? `· ${settings.secpRegistrationInfo}` : ''}
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-stone-400">
            <button onClick={() => onNavigate('register')} className="hover:text-white transition-colors cursor-pointer">
              Register Account
            </button>
            <button onClick={() => onNavigate('login')} className="hover:text-white transition-colors cursor-pointer">
              Farmer Login
            </button>
            <a
              href={settings.whatsappAdmin || 'https://wa.me/'}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              WhatsApp Admin
            </a>
            <a
              href={settings.whatsappChannel || 'https://whatsapp.com/channel/'}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              WhatsApp Channel
            </a>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500">
          <p>© {new Date().getFullYear()} EGGS NAVA DIGITAL FARM. All rights reserved.</p>
          <p>Naturally raised · Farm-fresh quality · Fresh daily</p>
        </div>
      </footer>
    </div>
  );
};
