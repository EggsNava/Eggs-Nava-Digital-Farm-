import React, { useState, useEffect } from 'react';
import {
  Copy,
  Check,
  MessageCircle,
  Radio,
  LogOut,
  ShieldCheck,
  Clock,
  CheckCircle2,
  Home,
  ShoppingBag,
  TrendingUp,
} from 'lucide-react';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  DepositRequest,
  EggBuyer,
  EggSale,
  FarmPlan,
  HenOrder,
  PlatformSettings,
  TransactionRecord,
  UserAccount,
  UserPublic,
  WithdrawalRequest,
} from '../types';
import { FarmMarket } from './FarmMarket';
import { EggMarket } from './EggMarket';
import { FARM_IMAGES } from '../constants/assets';

interface UserDashboardProps {
  userAccount: UserAccount;
  plans: FarmPlan[];
  buyers: EggBuyer[];
  settings: PlatformSettings;
  deposits: DepositRequest[];
  henOrders: HenOrder[];
  eggSales: EggSale[];
  withdrawals: WithdrawalRequest[];
  transactions: TransactionRecord[];
  teamMembers: UserPublic[];
  isAdmin: boolean;
  onNavigateApp: (mode: 'home' | 'login' | 'register' | 'welcome' | 'dashboard' | 'admin') => void;
}

type NavTab =
  | 'dashboard'
  | 'my-farms'
  | 'buy-products'
  | 'sell-assets'
  | 'my-profile'
  | 'deposits'
  | 'withdrawals'
  | 'team'
  | 'transactions'
  | 'rewards'
  | 'fbr';

export const UserDashboard: React.FC<UserDashboardProps> = ({
  userAccount,
  plans,
  buyers,
  settings,
  deposits,
  henOrders,
  eggSales,
  withdrawals,
  transactions,
  teamMembers,
  isAdmin,
  onNavigateApp,
}) => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [copiedRef, setCopiedRef] = useState(false);

  // Live 24-hour harvest countdown timer
  const [timerLabel, setTimerLabel] = useState<string>('');
  const [canHarvestNow, setCanHarvestNow] = useState<boolean>(false);
  const [harvesting, setHarvesting] = useState<boolean>(false);
  const [harvestMessage, setHarvestMessage] = useState<string | null>(null);

  // Deposit Form State
  const [depMethod, setDepMethod] = useState<string>('JazzCash');
  const [depAmount, setDepAmount] = useState<string>('1000');
  const [depRefId, setDepRefId] = useState<string>('');
  const [depProof, setDepProof] = useState<string>('');
  const [depSubmitting, setDepSubmitting] = useState(false);
  const [depSuccess, setDepSuccess] = useState<string | null>(null);
  const [depError, setDepError] = useState<string | null>(null);

  // Withdrawal Form State
  const [wdAmount, setWdAmount] = useState<string>('500');
  const [wdMethod, setWdMethod] = useState<string>('JazzCash');
  const [wdDetails, setWdDetails] = useState<string>(userAccount.phone || '');
  const [wdSubmitting, setWdSubmitting] = useState(false);
  const [wdSuccess, setWdSuccess] = useState<string | null>(null);
  const [wdError, setWdError] = useState<string | null>(null);

  // Profile Form State
  const [profilePhone, setProfilePhone] = useState<string>(userAccount.phone || '');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileSavedMsg, setProfileSavedMsg] = useState<string | null>(null);

  // Transaction filter
  const [txFilter, setTxFilter] = useState<string>('ALL');

  const approvedHenOrders = henOrders.filter((o) => o.status === 'Approved');
  const totalDailyEggsFromPlans = approvedHenOrders.reduce((sum, o) => sum + (o.totalDailyEggs || 0), 0);
  const effectiveDailyEggs = totalDailyEggsFromPlans > 0 ? totalDailyEggsFromPlans : userAccount.activeHens;

  useEffect(() => {
    const updateTimer = () => {
      if (userAccount.activeHens <= 0) {
        setTimerLabel('Buy a hen plan to start the timer');
        setCanHarvestNow(false);
        return;
      }

      if (!userAccount.lastHarvestAt) {
        setTimerLabel('Ready to collect daily eggs now');
        setCanHarvestNow(true);
        return;
      }

      const lastTime = new Date(userAccount.lastHarvestAt).getTime();
      const nextTime = lastTime + 24 * 60 * 60 * 1000;
      const now = Date.now();
      const diff = nextTime - now;

      if (diff <= 0) {
        setTimerLabel('Ready to collect daily eggs now');
        setCanHarvestNow(true);
      } else {
        const hrs = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        setTimerLabel(
          `${String(hrs).padStart(2, '0')}h : ${String(mins).padStart(2, '0')}m : ${String(secs).padStart(2, '0')}s`
        );
        setCanHarvestNow(false);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [userAccount.activeHens, userAccount.lastHarvestAt]);

  const referralLink = `${window.location.origin}/signup?ref=${userAccount.referralCode || userAccount.username}`;

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  const handleDailyHarvest = async () => {
    if (userAccount.activeHens <= 0 || !canHarvestNow || harvesting) return;
    setHarvesting(true);
    setHarvestMessage(null);

    const now = new Date().toISOString();
    const eggsToCollect = Math.max(1, effectiveDailyEggs);
    const txId = `tx_harvest_${Date.now()}_${userAccount.uid.slice(0, 6)}`;

    const txDoc: TransactionRecord = {
      id: txId,
      userId: userAccount.uid,
      username: userAccount.username,
      type: 'Egg Profit',
      amount: eggsToCollect,
      unit: 'EGGS',
      status: 'Approved',
      referenceId: `HARVEST-${now.slice(0, 10)}`,
      description: `Daily Egg Harvest from ${userAccount.activeHens} Active Hens`,
      createdAt: now,
    };

    try {
      await updateDoc(doc(db, 'users', userAccount.uid), {
        eggsBalance: (userAccount.eggsBalance || 0) + eggsToCollect,
        totalEggsProfit: (userAccount.totalEggsProfit || 0) + eggsToCollect,
        lastHarvestAt: now,
        updatedAt: now,
      });

      await setDoc(doc(db, 'transactions', txId), txDoc);

      for (const order of approvedHenOrders) {
        await updateDoc(doc(db, 'hen_orders', order.id), {
          lastHarvestDate: now,
          eggsAccumulated: (order.eggsAccumulated || 0) + (order.totalDailyEggs || 0),
          updatedAt: now,
        });
      }

      setHarvestMessage(`Successfully harvested ${eggsToCollect} fresh brown eggs into your Egg Balance!`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userAccount.uid}`);
    } finally {
      setHarvesting(false);
    }
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDepError(null);
    setDepSuccess(null);

    const numAmount = Number(depAmount);
    if (!numAmount || numAmount <= 0) {
      setDepError('Please enter a valid deposit amount in PKR.');
      return;
    }
    if (depRefId.trim().length < 2) {
      setDepError('Please enter your Transaction / Reference ID.');
      return;
    }

    setDepSubmitting(true);
    const now = new Date().toISOString();
    const depId = `dep_${Date.now()}_${userAccount.uid.slice(0, 6)}`;
    const txId = `tx_${Date.now()}_${userAccount.uid.slice(0, 6)}`;

    const depDoc: DepositRequest = {
      id: depId,
      userId: userAccount.uid,
      username: userAccount.username,
      amount: numAmount,
      paymentMethod: depMethod,
      referenceId: depRefId.trim().slice(0, 120),
      proofNote: depProof.trim().slice(0, 500),
      status: 'Pending',
      createdAt: now,
      updatedAt: now,
    };

    const txDoc: TransactionRecord = {
      id: txId,
      userId: userAccount.uid,
      username: userAccount.username,
      type: 'Deposit',
      amount: numAmount,
      unit: 'PKR',
      status: 'Pending',
      referenceId: depRefId.trim().slice(0, 120),
      description: `Deposit via ${depMethod} — Pending Admin Verification`,
      createdAt: now,
    };

    try {
      await setDoc(doc(db, 'deposits', depId), depDoc);
      await setDoc(doc(db, 'transactions', txId), txDoc);
      setDepRefId('');
      setDepProof('');
      setDepSuccess(
        `Deposit request for PKR ${numAmount.toLocaleString()} submitted (Status: Pending). Your Available Balance will update once Admin approves the transaction.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `deposits/${depId}`);
    } finally {
      setDepSubmitting(false);
    }
  };

  const handleWithdrawalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setWdError(null);
    setWdSuccess(null);

    const numAmount = Number(wdAmount);
    if (!numAmount || numAmount <= 0) {
      setWdError('Please enter a valid withdrawal amount.');
      return;
    }
    if (numAmount > userAccount.availableBalance) {
      setWdError(
        `Insufficient Available Balance. Your current balance is PKR ${userAccount.availableBalance.toLocaleString()}.`
      );
      return;
    }
    if (wdDetails.trim().length < 3) {
      setWdError('Please enter your receiving account title and number.');
      return;
    }

    setWdSubmitting(true);
    const now = new Date().toISOString();
    const wdId = `wd_${Date.now()}_${userAccount.uid.slice(0, 6)}`;
    const txId = `tx_${Date.now()}_${userAccount.uid.slice(0, 6)}`;

    const wdDoc: WithdrawalRequest = {
      id: wdId,
      userId: userAccount.uid,
      username: userAccount.username,
      amount: numAmount,
      payoutMethod: wdMethod,
      accountDetails: wdDetails.trim().slice(0, 250),
      status: 'Pending',
      createdAt: now,
      updatedAt: now,
    };

    const txDoc: TransactionRecord = {
      id: txId,
      userId: userAccount.uid,
      username: userAccount.username,
      type: 'Withdrawal',
      amount: numAmount,
      unit: 'PKR',
      status: 'Pending',
      referenceId: wdId,
      description: `Withdrawal via ${wdMethod} (${wdDetails.trim().slice(0, 60)}) — Pending Admin Approval`,
      createdAt: now,
    };

    try {
      await setDoc(doc(db, 'withdrawals', wdId), wdDoc);
      await setDoc(doc(db, 'transactions', txId), txDoc);
      setWdSuccess(
        `Withdrawal request for PKR ${numAmount.toLocaleString()} submitted (Status: Pending). Payout will be processed upon Admin approval.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `withdrawals/${wdId}`);
    } finally {
      setWdSubmitting(false);
    }
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (profilePhone.trim().length < 7) return;
    setProfileSaving(true);
    setProfileSavedMsg(null);
    const now = new Date().toISOString();
    try {
      await updateDoc(doc(db, 'users', userAccount.uid), {
        phone: profilePhone.trim().slice(0, 25),
        updatedAt: now,
      });
      setProfileSavedMsg('Your farmer profile phone number has been updated in Firebase.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userAccount.uid}`);
    } finally {
      setProfileSaving(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    onNavigateApp('home');
  };

  const pendingHensCount = henOrders
    .filter((o) => o.status === 'Pending')
    .reduce((sum, o) => sum + o.quantity, 0);
  const pendingEggsCount = eggSales
    .filter((s) => s.status === 'Pending')
    .reduce((sum, s) => sum + s.eggQuantity, 0);

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-stone-900 pb-20 md:pb-12 flex flex-col">
      {/* Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white border-b border-stone-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="text-lg font-bold tracking-tight text-stone-900 font-display whitespace-nowrap cursor-pointer"
          >
            EGGS NAVA DIGITAL FARM
          </button>

          {/* Required Navigation: Dashboard, My Farms, Buy Products, Sell Assets, My Profile, Logout */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-stone-600">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'dashboard' ? 'text-amber-800 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('my-farms')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'my-farms' ? 'text-amber-800 font-semibold underline underline-offset-8' : ''
              }`}
            >
              My Farms
            </button>
            <button
              onClick={() => setActiveTab('buy-products')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'buy-products' ? 'text-amber-800 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Buy Products
            </button>
            <button
              onClick={() => setActiveTab('sell-assets')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'sell-assets' ? 'text-amber-800 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Sell Assets
            </button>
            <button
              onClick={() => setActiveTab('my-profile')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'my-profile' ? 'text-amber-800 font-semibold underline underline-offset-8' : ''
              }`}
            >
              My Profile
            </button>
          </nav>

          <div className="flex items-center gap-2.5">
            {isAdmin && (
              <button
                onClick={() => onNavigateApp('admin')}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                Admin Panel
              </button>
            )}
            <button
              onClick={handleLogout}
              className="px-3.5 py-2 text-xs font-semibold text-stone-700 border border-stone-300 hover:bg-stone-100 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* Welcome Back & Core Farmer Summary Strip (Always visible at top of Dashboard) */}
        <section className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-200">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 mb-1">
                <span>Welcome back</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-800 font-semibold">
                  {userAccount.verifiedFarmer ? 'Verified Farmer' : 'Standard Account'}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Referred by:{' '}
                  <strong className="font-mono text-stone-800">
                    {userAccount.referredBy ? `@${userAccount.referredBy}` : 'Direct Member'}
                  </strong>
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-stone-900">
                @{userAccount.username}
              </h1>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveTab('deposits')}
                className="px-4 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Deposit Funds
              </button>
              <button
                onClick={() => setActiveTab('withdrawals')}
                className="px-4 py-2.5 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Withdraw Balance
              </button>
              <button
                onClick={() => setActiveTab('transactions')}
                className="px-4 py-2.5 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Ledger History
              </button>
            </div>
          </div>

          {/* Primary 4 Metrics: Available Balance, Eggs, Active Flock, Total Hens */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
            <div>
              <p className="text-xs text-stone-500">Available Balance</p>
              <p className="text-2xl font-bold text-stone-900 font-mono tabular-nums mt-1">
                PKR {userAccount.availableBalance.toLocaleString()}
              </p>
              <p className="text-xs text-stone-500 mt-0.5">Verified wallet funds</p>
            </div>

            <div>
              <p className="text-xs text-stone-500">Eggs</p>
              <p className="text-2xl font-bold text-amber-800 font-mono tabular-nums mt-1">
                {userAccount.eggsBalance.toLocaleString()} Eggs
              </p>
              <p className="text-xs text-stone-500 mt-0.5">Available for sale</p>
            </div>

            <div>
              <p className="text-xs text-stone-500">Active Flock</p>
              <p className="text-2xl font-bold text-emerald-800 font-mono tabular-nums mt-1">
                {userAccount.activeHens.toLocaleString()} Hens
              </p>
              <p className="text-xs text-stone-500 mt-0.5">Producing daily eggs</p>
            </div>

            <div>
              <p className="text-xs text-stone-500">Total Hens</p>
              <p className="text-2xl font-bold text-stone-900 font-mono tabular-nums mt-1">
                {userAccount.totalHens.toLocaleString()} Hens
              </p>
              <p className="text-xs text-stone-500 mt-0.5">Cumulative farm flock</p>
            </div>
          </div>
        </section>

        {/* Sub-view Routing */}
        {activeTab === 'buy-products' && (
          <FarmMarket
            plans={plans}
            settings={settings}
            userAccount={userAccount}
            onSuccessOrder={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'sell-assets' && (
          <EggMarket
            buyers={buyers}
            userAccount={userAccount}
            settings={settings}
            eggSales={eggSales}
          />
        )}

        {activeTab === 'my-farms' && (
          <div className="space-y-6">
            <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
                    Active Hen Plans & Egg Earnings
                  </p>
                  <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                    My Farms & Flock Production
                  </h2>
                </div>
                <button
                  onClick={() => setActiveTab('buy-products')}
                  className="px-4 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  Buy More Hens
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-stone-50 border border-stone-200 mb-6">
                <div>
                  <p className="text-xs text-stone-500">Number of Active Hens</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums">
                    {userAccount.activeHens}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-stone-500">Daily Egg Production</p>
                  <p className="text-lg font-bold text-emerald-800 font-mono tabular-nums">
                    {effectiveDailyEggs} Eggs / day
                  </p>
                </div>
                <div>
                  <p className="text-xs text-stone-500">Eggs Accumulated</p>
                  <p className="text-lg font-bold text-amber-800 font-mono tabular-nums">
                    {userAccount.eggsBalance} Eggs
                  </p>
                </div>
                <div>
                  <p className="text-xs text-stone-500">Total Egg Profit</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums">
                    {userAccount.totalEggsProfit} Eggs
                  </p>
                </div>
              </div>

              {henOrders.length === 0 ? (
                <div className="text-center py-10 border border-dashed border-stone-300 rounded-xl">
                  <p className="text-sm font-semibold text-stone-800">No active or pending hen plans yet</p>
                  <p className="text-xs text-stone-500 mt-1 mb-4">
                    Purchase a Golden Hen or Pasture Flock package to start your daily egg harvest timer.
                  </p>
                  <button
                    onClick={() => setActiveTab('buy-products')}
                    className="px-5 py-2.5 rounded-xl bg-amber-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Browse Hen Plans
                  </button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2.5 pr-4 font-semibold">Package</th>
                        <th className="py-2.5 pr-4 font-semibold text-right">Hens</th>
                        <th className="py-2.5 pr-4 font-semibold text-right">Daily Eggs</th>
                        <th className="py-2.5 pr-4 font-semibold text-right">Accumulated</th>
                        <th className="py-2.5 pr-4 font-semibold">Plan Start Date</th>
                        <th className="py-2.5 pr-4 font-semibold">Plan End Date</th>
                        <th className="py-2.5 font-semibold text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {henOrders.map((ord) => (
                        <tr key={ord.id}>
                          <td className="py-3 pr-4 font-sans font-semibold text-stone-900">
                            {ord.planName}
                          </td>
                          <td className="py-3 pr-4 text-right">{ord.quantity}</td>
                          <td className="py-3 pr-4 text-right text-emerald-800">
                            {ord.totalDailyEggs} / day
                          </td>
                          <td className="py-3 pr-4 text-right text-amber-800">
                            {ord.eggsAccumulated} Eggs
                          </td>
                          <td className="py-3 pr-4 text-stone-600">
                            {ord.startDate ? ord.startDate.slice(0, 10) : 'Upon Approval'}
                          </td>
                          <td className="py-3 pr-4 text-stone-600">
                            {ord.endDate ? ord.endDate.slice(0, 10) : `${ord.durationDays} Days`}
                          </td>
                          <td className="py-3 text-right font-sans font-semibold">
                            <span
                              className={
                                ord.status === 'Approved'
                                  ? 'text-emerald-800'
                                  : ord.status === 'Rejected'
                                  ? 'text-red-700'
                                  : 'text-amber-800'
                              }
                            >
                              {ord.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'deposits' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                  Deposit System
                </p>
                <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                  Add Balance to Your Farm Wallet
                </h2>
                <p className="text-xs text-stone-600 mt-1">{settings.depositInstructions}</p>
              </div>

              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 space-y-2 text-xs">
                <p className="font-semibold text-stone-900">Admin Receiving Gateways:</p>
                <p>
                  <span className="text-stone-500">JazzCash:</span>{' '}
                  <strong className="font-mono">{settings.jazzCashNumber}</strong> ({settings.jazzCashTitle})
                </p>
                <p>
                  <span className="text-stone-500">EasyPaisa:</span>{' '}
                  <strong className="font-mono">{settings.easyPaisaNumber}</strong> ({settings.easyPaisaTitle})
                </p>
                <p>
                  <span className="text-stone-500">SadaPay:</span>{' '}
                  <strong className="font-mono">{settings.sadaPayNumber}</strong> ({settings.sadaPayTitle})
                </p>
                <p>
                  <span className="text-stone-500">UPaisa:</span>{' '}
                  <strong className="font-mono">{settings.uPaisaNumber}</strong> ({settings.uPaisaTitle})
                </p>
                <p>
                  <span className="text-stone-500">Bank ({settings.bankName}):</span>{' '}
                  <strong className="font-mono">{settings.bankAccountNumber}</strong> · IBAN: {settings.bankIban}
                </p>
              </div>

              {depError && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                  {depError}
                </div>
              )}
              {depSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                  {depSuccess}
                </div>
              )}

              <form onSubmit={handleDepositSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Select Payment Method
                  </label>
                  <select
                    value={depMethod}
                    onChange={(e) => setDepMethod(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm"
                  >
                    <option value="JazzCash">JazzCash</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="Bank Account">Bank Account</option>
                    <option value="SadaPay">SadaPay</option>
                    <option value="UPaisa">UPaisa</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Deposit Amount (PKR)
                  </label>
                  <input
                    type="number"
                    min={100}
                    required
                    value={depAmount}
                    onChange={(e) => setDepAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Transaction / Reference ID
                  </label>
                  <input
                    type="text"
                    required
                    value={depRefId}
                    onChange={(e) => setDepRefId(e.target.value)}
                    placeholder="Enter Trx ID / Bank Reference"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Payment Proof Note / Sender Details
                  </label>
                  <input
                    type="text"
                    value={depProof}
                    onChange={(e) => setDepProof(e.target.value)}
                    placeholder="Sender mobile number & account name"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={depSubmitting}
                  className="w-full py-3.5 px-5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  {depSubmitting ? 'Submitting Deposit Request...' : 'Submit Deposit Request'}
                </button>
              </form>
            </div>

            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
              <h3 className="text-lg font-bold text-stone-900 mb-4">Your Deposit History</h3>
              {deposits.length === 0 ? (
                <p className="text-xs text-stone-500 py-6">No deposit requests submitted yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2.5 pr-3 font-semibold">Date</th>
                        <th className="py-2.5 pr-3 font-semibold">Method</th>
                        <th className="py-2.5 pr-3 font-semibold">Ref ID</th>
                        <th className="py-2.5 pr-3 font-semibold text-right">Amount</th>
                        <th className="py-2.5 font-semibold text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {deposits.map((d) => (
                        <tr key={d.id}>
                          <td className="py-3 pr-3 text-stone-600">{d.createdAt.slice(0, 10)}</td>
                          <td className="py-3 pr-3 font-sans text-stone-900">{d.paymentMethod}</td>
                          <td className="py-3 pr-3 text-stone-600">{d.referenceId}</td>
                          <td className="py-3 pr-3 text-right font-semibold text-stone-900">
                            PKR {d.amount.toLocaleString()}
                          </td>
                          <td className="py-3 text-right font-sans font-semibold">
                            <span
                              className={
                                d.status === 'Approved'
                                  ? 'text-emerald-800'
                                  : d.status === 'Rejected'
                                  ? 'text-red-700'
                                  : 'text-amber-800'
                              }
                            >
                              {d.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'withdrawals' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                  Withdrawal System
                </p>
                <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                  Withdraw Farm Earnings
                </h2>
                <p className="text-xs text-stone-600 mt-1">{settings.withdrawalInstructions}</p>
              </div>

              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                <span className="text-xs text-stone-500">Available Balance for Withdrawal</span>
                <span className="text-lg font-bold text-emerald-800 font-mono tabular-nums">
                  PKR {userAccount.availableBalance.toLocaleString()}
                </span>
              </div>

              {wdError && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                  {wdError}
                </div>
              )}
              {wdSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                  {wdSuccess}
                </div>
              )}

              <form onSubmit={handleWithdrawalSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Withdrawal Amount (PKR)
                  </label>
                  <input
                    type="number"
                    min={100}
                    required
                    value={wdAmount}
                    onChange={(e) => setWdAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Select Payout Method
                  </label>
                  <select
                    value={wdMethod}
                    onChange={(e) => setWdMethod(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm"
                  >
                    <option value="JazzCash">JazzCash</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="Bank Account">Bank Account</option>
                    <option value="SadaPay">SadaPay</option>
                    <option value="UPaisa">UPaisa</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Receiving Account Details (Account Title & Number / IBAN)
                  </label>
                  <input
                    type="text"
                    required
                    value={wdDetails}
                    onChange={(e) => setWdDetails(e.target.value)}
                    placeholder="e.g. Ahmad Khan - 03001234567"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono"
                  />
                </div>

                <button
                  type="submit"
                  disabled={wdSubmitting}
                  className="w-full py-3.5 px-5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  {wdSubmitting ? 'Submitting Request...' : 'Submit Withdrawal Request'}
                </button>
              </form>
            </div>

            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
              <h3 className="text-lg font-bold text-stone-900 mb-4">Withdrawal History</h3>
              {withdrawals.length === 0 ? (
                <p className="text-xs text-stone-500 py-6">No withdrawal requests submitted yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2.5 pr-3 font-semibold">Date</th>
                        <th className="py-2.5 pr-3 font-semibold">Method</th>
                        <th className="py-2.5 pr-3 font-semibold">Account</th>
                        <th className="py-2.5 pr-3 font-semibold text-right">Amount</th>
                        <th className="py-2.5 font-semibold text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {withdrawals.map((w) => (
                        <tr key={w.id}>
                          <td className="py-3 pr-3 text-stone-600">{w.createdAt.slice(0, 10)}</td>
                          <td className="py-3 pr-3 font-sans text-stone-900">{w.payoutMethod}</td>
                          <td className="py-3 pr-3 text-stone-600">{w.accountDetails}</td>
                          <td className="py-3 pr-3 text-right font-semibold text-stone-900">
                            PKR {w.amount.toLocaleString()}
                          </td>
                          <td className="py-3 text-right font-sans font-semibold">
                            <span
                              className={
                                w.status === 'Approved'
                                  ? 'text-emerald-800'
                                  : w.status === 'Rejected'
                                  ? 'text-red-700'
                                  : 'text-amber-800'
                              }
                            >
                              {w.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'team' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Farmer Referral Network
              </p>
              <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                Your Team & Referral Bonus
              </h2>
              <p className="text-xs text-stone-600 mt-1">{settings.referralRules}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                <p className="text-xs text-stone-500">Total Referrals</p>
                <p className="text-2xl font-bold text-stone-900 font-mono tabular-nums mt-1">
                  {Math.max(userAccount.totalReferrals, teamMembers.length)}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                <p className="text-xs text-stone-500">Active Team</p>
                <p className="text-2xl font-bold text-emerald-800 font-mono tabular-nums mt-1">
                  {Math.max(userAccount.activeTeam, teamMembers.filter((m) => m.status === 'active').length)}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                <p className="text-xs text-stone-500">Referral Bonus Earned</p>
                <p className="text-2xl font-bold text-amber-800 font-mono tabular-nums mt-1">
                  PKR {userAccount.referralBonus.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="overflow-hidden">
                <p className="text-xs text-stone-500 mb-0.5">Personal Referral Link</p>
                <p className="text-xs sm:text-sm font-mono font-semibold text-stone-900 truncate">
                  {referralLink}
                </p>
              </div>
              <button
                onClick={handleCopyReferral}
                className="px-4 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                {copiedRef ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedRef ? 'Copied!' : 'Copy Link'}</span>
              </button>
            </div>

            <div>
              <h3 className="text-base font-bold text-stone-900 mb-3">Referred Farmers History</h3>
              {teamMembers.length === 0 ? (
                <p className="text-xs text-stone-500 py-4">
                  No farmers have registered with your referral link yet. Share your link above to grow your team.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2.5 pr-4 font-semibold">Farmer Username</th>
                        <th className="py-2.5 pr-4 font-semibold">Joined Date</th>
                        <th className="py-2.5 font-semibold text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono">
                      {teamMembers.map((member) => (
                        <tr key={member.uid}>
                          <td className="py-3 pr-4 font-semibold text-stone-900">@{member.username}</td>
                          <td className="py-3 pr-4 text-stone-600">{member.createdAt.slice(0, 10)}</td>
                          <td className="py-3 text-right font-sans font-semibold text-emerald-800">
                            {member.status}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                  Complete Ledger
                </p>
                <h2 className="text-2xl font-bold text-stone-900 mt-0.5">Transaction History</h2>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1 rounded-xl">
                {['ALL', 'Deposit', 'Hen Purchase', 'Egg Sale', 'Withdrawal', 'Referral Reward', 'Egg Profit'].map(
                  (type) => (
                    <button
                      key={type}
                      onClick={() => setTxFilter(type)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        txFilter === type
                          ? 'bg-white text-stone-900 shadow-xs font-semibold'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      {type}
                    </button>
                  )
                )}
              </div>
            </div>

            {transactions.length === 0 ? (
              <p className="text-xs text-stone-500 py-8 text-center">
                No transactions recorded on your account yet.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500">
                      <th className="py-2.5 pr-4 font-semibold">Date / Time</th>
                      <th className="py-2.5 pr-4 font-semibold">Type</th>
                      <th className="py-2.5 pr-4 font-semibold">Description</th>
                      <th className="py-2.5 pr-4 font-semibold">Ref ID</th>
                      <th className="py-2.5 pr-4 font-semibold text-right">Amount</th>
                      <th className="py-2.5 font-semibold text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                    {transactions
                      .filter((t) => txFilter === 'ALL' || t.type === txFilter)
                      .map((tx) => (
                        <tr key={tx.id}>
                          <td className="py-3 pr-4 text-stone-600">
                            {tx.createdAt.replace('T', ' ').slice(0, 16)}
                          </td>
                          <td className="py-3 pr-4 font-sans font-semibold text-stone-900">
                            {tx.type}
                          </td>
                          <td className="py-3 pr-4 font-sans text-stone-600">{tx.description}</td>
                          <td className="py-3 pr-4 text-stone-500">{tx.referenceId}</td>
                          <td className="py-3 pr-4 text-right font-semibold text-stone-900">
                            {tx.unit === 'PKR' ? `PKR ${tx.amount.toLocaleString()}` : `${tx.amount} ${tx.unit}`}
                          </td>
                          <td className="py-3 text-right font-sans font-semibold">
                            <span
                              className={
                                tx.status === 'Approved'
                                  ? 'text-emerald-800'
                                  : tx.status === 'Rejected'
                                  ? 'text-red-700'
                                  : 'text-amber-800'
                              }
                            >
                              {tx.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'rewards' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Farmer Incentives & Milestones
              </p>
              <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                Rewards & Seasonal Prizes
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-5 rounded-xl bg-stone-50 border border-stone-200">
                <h3 className="text-base font-bold text-stone-900 mb-2">Flock Performance Rewards</h3>
                <p className="text-xs text-stone-600 leading-relaxed">{settings.rewardsInfo}</p>
              </div>
              <div className="p-5 rounded-xl bg-stone-50 border border-stone-200">
                <h3 className="text-base font-bold text-stone-900 mb-2">Community Reward Prizes</h3>
                <p className="text-xs text-stone-600 leading-relaxed">{settings.rewardPrizesInfo}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'fbr' && settings.fbrSecpEnabled && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
              Official Registration Details
            </p>
            <h2 className="text-2xl font-bold text-stone-900">FBR / SECP Information</h2>
            {settings.fbrRegistrationInfo && (
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 text-xs font-mono">
                {settings.fbrRegistrationInfo}
              </div>
            )}
            {settings.secpRegistrationInfo && (
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 text-xs font-mono">
                {settings.secpRegistrationInfo}
              </div>
            )}
          </div>
        )}

        {activeTab === 'my-profile' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 max-w-2xl space-y-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Farmer Account Details
              </p>
              <h2 className="text-2xl font-bold text-stone-900 mt-0.5">My Profile</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-stone-50 border border-stone-200 text-xs">
              <div>
                <p className="text-stone-500">Username</p>
                <p className="font-mono font-bold text-stone-900 text-sm mt-0.5">
                  @{userAccount.username}
                </p>
              </div>
              <div>
                <p className="text-stone-500">User ID</p>
                <p className="font-mono font-semibold text-stone-800 mt-0.5 break-all">
                  {userAccount.uid}
                </p>
              </div>
              <div>
                <p className="text-stone-500">Referral Code</p>
                <p className="font-mono font-bold text-amber-800 mt-0.5">
                  {userAccount.referralCode}
                </p>
              </div>
              <div>
                <p className="text-stone-500">Account Status</p>
                <p className="font-semibold text-emerald-800 mt-0.5 uppercase">
                  {userAccount.status} · {userAccount.verifiedFarmer ? 'Verified Farmer' : 'Standard'}
                </p>
              </div>
              <div>
                <p className="text-stone-500">Registration Date</p>
                <p className="font-mono text-stone-800 mt-0.5">
                  {userAccount.createdAt.slice(0, 10)}
                </p>
              </div>
              <div>
                <p className="text-stone-500">Referred By</p>
                <p className="font-mono text-stone-800 mt-0.5">
                  {userAccount.referredBy || 'None'}
                </p>
              </div>
            </div>

            {profileSavedMsg && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                {profileSavedMsg}
              </div>
            )}

            <form onSubmit={handleProfileSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Phone Number (WhatsApp / Mobile Wallet Contact)
                </label>
                <input
                  type="tel"
                  required
                  value={profilePhone}
                  onChange={(e) => setProfilePhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono"
                />
              </div>
              <button
                type="submit"
                disabled={profileSaving}
                className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                {profileSaving ? 'Saving Profile...' : 'Update Phone Number'}
              </button>
            </form>
          </div>
        )}

        {/* MAIN DASHBOARD OVERVIEW SECTIONS */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Primary Action Cards: Buy Hen, Sell Eggs, Referral */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Card 1: Buy Hen */}
              <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden flex flex-col justify-between">
                <div className="aspect-16/9 bg-stone-100 overflow-hidden">
                  <img
                    src={FARM_IMAGES.hen}
                    alt="Buy Hen - Grow your flock"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
                      Farm Market
                    </p>
                    <h2 className="text-xl font-bold text-stone-900 mt-0.5">Buy Hen</h2>
                    <p className="text-xs text-stone-600 mt-1">
                      Grow your flock with naturally raised brown laying hens and earn daily egg harvests.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('buy-products')}
                    className="mt-5 w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Grow your flock
                  </button>
                </div>
              </div>

              {/* Card 2: Sell Eggs */}
              <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden flex flex-col justify-between">
                <div className="aspect-16/9 bg-stone-100 overflow-hidden">
                  <img
                    src={FARM_IMAGES.eggs}
                    alt="Sell Eggs - Turn eggs into value"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                      Egg Rapid Market
                    </p>
                    <h2 className="text-xl font-bold text-stone-900 mt-0.5">Sell Eggs</h2>
                    <p className="text-xs text-stone-600 mt-1">
                      Turn eggs into value by selling directly to verified wholesale buyers at live rates.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('sell-assets')}
                    className="mt-5 w-full py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Turn eggs into value
                  </button>
                </div>
              </div>

              {/* Card 3: Referral */}
              <div className="bg-white border border-stone-200 rounded-2xl p-6 flex flex-col justify-between">
                <div>
                  <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    Community Growth
                  </p>
                  <h2 className="text-xl font-bold text-stone-900 mt-0.5">Referral</h2>
                  <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                    Invite fellow poultry farmers using your personal referral link and earn PKR{' '}
                    <span className="font-mono font-semibold text-stone-900">
                      {settings.defaultReferReward}
                    </span>{' '}
                    refer bonus per approved package.
                  </p>

                  <div className="mt-4 p-3.5 rounded-xl bg-stone-50 border border-stone-200">
                    <p className="text-[11px] text-stone-500 mb-1">Your Personal Referral Link</p>
                    <p className="text-xs font-mono font-semibold text-stone-900 break-all">
                      {referralLink}
                    </p>
                  </div>
                </div>

                <div className="mt-5 flex items-center gap-2.5">
                  <button
                    onClick={handleCopyReferral}
                    className="flex-1 py-3 px-4 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {copiedRef ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedRef ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('team')}
                    className="py-3 px-4 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    View Team
                  </button>
                </div>
              </div>
            </div>

            {/* Daily Harvest Timer & Pending Activity Row */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Daily Harvest */}
              <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                      Daily Harvest
                    </p>
                    <h2 className="text-2xl font-bold text-stone-900 mt-0.5">
                      Start collecting eggs
                    </h2>
                    <p className="text-xs text-stone-600 mt-1">
                      {userAccount.activeHens > 0
                        ? `Your active flock of ${userAccount.activeHens} hens produces ${effectiveDailyEggs} eggs every 24 hours.`
                        : 'Buy a hen plan to start the timer and collect daily farm-fresh eggs.'}
                    </p>
                  </div>

                  <div className="px-4 py-3 rounded-xl bg-stone-900 text-white font-mono text-right shrink-0">
                    <p className="text-[10px] text-stone-400 uppercase">Live Daily Harvest Timer</p>
                    <p className="text-sm font-bold text-amber-400 tabular-nums mt-0.5">
                      {timerLabel}
                    </p>
                  </div>
                </div>

                {harvestMessage && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>{harvestMessage}</span>
                  </div>
                )}

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  {userAccount.activeHens > 0 ? (
                    <button
                      onClick={handleDailyHarvest}
                      disabled={!canHarvestNow || harvesting}
                      className="px-6 py-3 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white text-xs font-semibold transition-colors cursor-pointer"
                    >
                      {harvesting
                        ? 'Collecting Daily Eggs...'
                        : canHarvestNow
                        ? `Collect ${effectiveDailyEggs} Daily Eggs Now`
                        : 'Timer Active — Next Harvest in Countdown'}
                    </button>
                  ) : (
                    <button
                      onClick={() => setActiveTab('buy-products')}
                      className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Buy a hen plan to start the timer
                    </button>
                  )}
                </div>
              </div>

              {/* Pending Activity */}
              <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                    Verification Queue
                  </p>
                  <h2 className="text-xl font-bold text-stone-900 mt-0.5">Pending Activity</h2>
                  <p className="text-xs text-stone-600 mt-1">
                    Requests awaiting manual Admin verification before balance updates.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                    <p className="text-xs text-stone-500">Pending Hen</p>
                    <p className="text-2xl font-bold text-amber-800 font-mono tabular-nums mt-1">
                      {pendingHensCount} Hens
                    </p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Awaiting approval</p>
                  </div>

                  <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                    <p className="text-xs text-stone-500">Pending Eggs</p>
                    <p className="text-2xl font-bold text-amber-800 font-mono tabular-nums mt-1">
                      {pendingEggsCount} Eggs
                    </p>
                    <p className="text-[11px] text-stone-500 mt-0.5">In sale queue</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Farm Performance */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
              <div className="mb-6">
                <p className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
                  Real-Time Firebase Metrics
                </p>
                <h2 className="text-xl font-bold text-stone-900 mt-0.5">Farm Performance</h2>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Active Hens</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-1">
                    {userAccount.activeHens}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Balance Eggs</p>
                  <p className="text-lg font-bold text-amber-800 font-mono tabular-nums mt-1">
                    {userAccount.eggsBalance}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Total Eggs Profit</p>
                  <p className="text-lg font-bold text-emerald-800 font-mono tabular-nums mt-1">
                    {userAccount.totalEggsProfit}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Referral Bonus</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-1">
                    PKR {userAccount.referralBonus.toLocaleString()}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Total Investment</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-1">
                    PKR {userAccount.totalInvestment.toLocaleString()}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
                  <p className="text-xs text-stone-500">Total Withdraw</p>
                  <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-1">
                    PKR {userAccount.totalWithdraw.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Access & Support/Contact Section */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Quick Access */}
              <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
                <h2 className="text-lg font-bold text-stone-900 mb-4">Quick Access</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <button
                    onClick={() => setActiveTab('rewards')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Rewards</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Flock milestones</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('rewards')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Reward Prizes</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Seasonal awards</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('team')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Team</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Referred farmers</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('deposits')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Deposits</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Add farm funds</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('withdrawals')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Withdrawals</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Payout requests</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('my-farms')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Profit Egg</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">Harvest ledger</p>
                  </button>

                  <button
                    onClick={() => setActiveTab('team')}
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Refer Bonus</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">PKR {settings.defaultReferReward}</p>
                  </button>

                  {settings.appDownloadUrl ? (
                    <a
                      href={settings.appDownloadUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 text-left transition-colors"
                    >
                      <p className="text-xs font-bold text-stone-900">App Download</p>
                      <p className="text-[11px] text-emerald-800 mt-0.5">Get Mobile App</p>
                    </a>
                  ) : (
                    <button
                      onClick={() => setActiveTab('my-profile')}
                      className="p-3.5 rounded-xl border border-stone-200 hover:border-stone-300 text-left transition-colors cursor-pointer"
                    >
                      <p className="text-xs font-bold text-stone-900">App Download</p>
                      <p className="text-[11px] text-stone-500 mt-0.5">Web App Active</p>
                    </button>
                  )}

                  {/* Only display FBR/SECP if legitimate info is enabled & configured by Admin */}
                  {settings.fbrSecpEnabled &&
                    (settings.fbrRegistrationInfo || settings.secpRegistrationInfo) && (
                      <button
                        onClick={() => setActiveTab('fbr')}
                        className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/40 text-left transition-colors cursor-pointer"
                      >
                        <p className="text-xs font-bold text-emerald-900">FBR / SECP</p>
                        <p className="text-[11px] text-emerald-800 mt-0.5">View Registration</p>
                      </button>
                    )}
                </div>
              </div>

              {/* Support / Contact Section */}
              <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 flex flex-col justify-between">
                <div>
                  <h2 className="text-lg font-bold text-stone-900 mb-1">
                    Farmer Support & WhatsApp Community
                  </h2>
                  <p className="text-xs text-stone-600 mb-5">
                    Direct assistance from Admin & Owner, plus daily egg market announcements.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <a
                    href={settings.whatsappAdmin || 'https://wa.me/'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-emerald-700 hover:bg-emerald-50/30 flex items-center gap-2.5 text-xs font-semibold text-stone-900 transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>WhatsApp Admin</span>
                  </a>

                  <a
                    href={settings.whatsappOwner || 'https://wa.me/'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-emerald-700 hover:bg-emerald-50/30 flex items-center gap-2.5 text-xs font-semibold text-stone-900 transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>WhatsApp Owner</span>
                  </a>

                  <a
                    href={settings.whatsappChannel || 'https://whatsapp.com/channel/'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-amber-700 hover:bg-amber-50/30 flex items-center gap-2.5 text-xs font-semibold text-stone-900 transition-colors whitespace-nowrap"
                  >
                    <Radio className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>WhatsApp Channel</span>
                  </a>

                  <a
                    href={settings.whatsappGroup || 'https://chat.whatsapp.com/'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-xl border border-stone-200 hover:border-emerald-700 hover:bg-emerald-50/30 flex items-center gap-2.5 text-xs font-semibold text-stone-900 transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-800 shrink-0" />
                    <span>WhatsApp Group</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Mobile Navigation: Home, Buy, Sell (strictly <= 15% mobile viewport height) */}
      <nav className="fixed bottom-0 inset-x-0 z-30 md:hidden bg-white border-t border-stone-200 px-6 py-2.5 flex items-center justify-around">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center gap-1 text-xs font-semibold cursor-pointer ${
            activeTab === 'dashboard' ? 'text-amber-800' : 'text-stone-500'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Home</span>
        </button>

        <button
          onClick={() => setActiveTab('buy-products')}
          className={`flex flex-col items-center gap-1 text-xs font-semibold cursor-pointer ${
            activeTab === 'buy-products' ? 'text-amber-800' : 'text-stone-500'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Buy</span>
        </button>

        <button
          onClick={() => setActiveTab('sell-assets')}
          className={`flex flex-col items-center gap-1 text-xs font-semibold cursor-pointer ${
            activeTab === 'sell-assets' ? 'text-amber-800' : 'text-stone-500'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Sell</span>
        </button>
      </nav>
    </div>
  );
};
