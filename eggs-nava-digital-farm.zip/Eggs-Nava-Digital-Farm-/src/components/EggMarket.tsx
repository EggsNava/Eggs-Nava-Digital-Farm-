import React, { useState } from 'react';
import { CheckCircle2, Star, ShieldCheck } from 'lucide-react';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { EggBuyer, EggSale, PlatformSettings, TransactionRecord, UserAccount } from '../types';
import { FARM_IMAGES } from '../constants/assets';

interface EggMarketProps {
  buyers: EggBuyer[];
  userAccount: UserAccount;
  settings: PlatformSettings;
  eggSales: EggSale[];
}

export const EggMarket: React.FC<EggMarketProps> = ({
  buyers,
  userAccount,
  eggSales,
}) => {
  const activeBuyers = buyers.filter((b) => b.active);
  const [selectedBuyerId, setSelectedBuyerId] = useState<string>(activeBuyers[0]?.id || '');
  const [eggQuantity, setEggQuantity] = useState<string>('10');
  const [payoutMethod, setPayoutMethod] = useState<string>('JazzCash');
  const [payoutAccountDetails, setPayoutAccountDetails] = useState<string>(userAccount.phone || '');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const selectedBuyer =
    activeBuyers.find((b) => b.id === selectedBuyerId) ||
    activeBuyers[0] || {
      id: 'default_buyer',
      name: 'Al-Noor Organic Wholesale',
      rating: 4.9,
      tradesCount: 412,
      ratePerEgg: 28,
      successRate: 99.2,
      minQty: 1,
      maxQty: 5000,
      active: true,
      updatedAt: '',
    };

  const bestRate = activeBuyers.length > 0 ? Math.max(...activeBuyers.map((b) => b.ratePerEgg)) : 28;
  const parsedQty = Math.max(0, Math.floor(Number(eggQuantity) || 0));
  const calculatedPayout = parsedQty * selectedBuyer.ratePerEgg;

  const handleSellSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (parsedQty < selectedBuyer.minQty || parsedQty > selectedBuyer.maxQty) {
      setErrorMsg(
        `Quantity for ${selectedBuyer.name} must be between ${selectedBuyer.minQty} and ${selectedBuyer.maxQty} eggs.`
      );
      return;
    }

    if (parsedQty > userAccount.eggsBalance) {
      setErrorMsg(
        `Insufficient Available Eggs. You currently have ${userAccount.eggsBalance} eggs ready to sell.`
      );
      return;
    }

    if (payoutAccountDetails.trim().length < 3) {
      setErrorMsg('Please enter your receiving account title and number.');
      return;
    }

    setSubmitting(true);
    const now = new Date().toISOString();
    const saleId = `sale_${Date.now()}_${userAccount.uid.slice(0, 6)}`;
    const txId = `tx_${Date.now()}_${userAccount.uid.slice(0, 6)}`;

    const saleDoc: EggSale = {
      id: saleId,
      userId: userAccount.uid,
      username: userAccount.username,
      buyerId: selectedBuyer.id,
      buyerName: selectedBuyer.name,
      eggQuantity: parsedQty,
      ratePerEgg: selectedBuyer.ratePerEgg,
      totalPayout: calculatedPayout,
      payoutMethod,
      payoutAccountDetails: payoutAccountDetails.trim().slice(0, 250),
      status: 'Pending',
      createdAt: now,
      updatedAt: now,
    };

    const txDoc: TransactionRecord = {
      id: txId,
      userId: userAccount.uid,
      username: userAccount.username,
      type: 'Egg Sale',
      amount: calculatedPayout,
      unit: 'PKR',
      status: 'Pending',
      referenceId: saleId,
      description: `Sell ${parsedQty} Eggs to ${selectedBuyer.name} @ PKR ${selectedBuyer.ratePerEgg}/egg`,
      createdAt: now,
    };

    try {
      await setDoc(doc(db, 'egg_sales', saleId), saleDoc);
      await setDoc(doc(db, 'transactions', txId), txDoc);
      await updateDoc(doc(db, 'users', userAccount.uid), {
        pendingEggs: (userAccount.pendingEggs || 0) + parsedQty,
        updatedAt: now,
      });
      setSuccessMsg(
        `Sell request for ${parsedQty} eggs (PKR ${calculatedPayout.toLocaleString()}) submitted with Status = Pending. Your egg balance will be deducted and payout credited upon Admin approval.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `egg_sales/${saleId}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Egg Rapid Banner */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-8 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-800 uppercase tracking-wider">
            <span>Egg Rapid</span>
            <span aria-hidden="true">·</span>
            <span>Dashboard / Fresh Farm Market</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-stone-900">
            Sell eggs. Earn securely.
          </h1>
          <p className="text-sm text-stone-600 max-w-xl">
            Trade your harvested brown eggs directly with verified wholesale buyers. Select a buyer card below, enter your egg quantity, and submit a sale request.
          </p>

          <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200">
              <p className="text-xs text-stone-500">Available Eggs</p>
              <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-0.5">
                {userAccount.eggsBalance.toLocaleString()}
              </p>
              <p className="text-[11px] text-emerald-800">Eggs ready to sell</p>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200">
              <p className="text-xs text-stone-500">Market Status</p>
              <p className="text-lg font-bold text-emerald-800 mt-0.5">Market Open</p>
              <p className="text-[11px] text-stone-500">Instant order logging</p>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200">
              <p className="text-xs text-stone-500">Best Rate</p>
              <p className="text-lg font-bold text-amber-800 font-mono tabular-nums mt-0.5">
                PKR {bestRate} / Egg
              </p>
              <p className="text-[11px] text-stone-500">Live wholesale rate</p>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200">
              <p className="text-xs text-stone-500">Sale Status</p>
              <p className="text-lg font-bold text-stone-900 font-mono tabular-nums mt-0.5">
                {userAccount.pendingEggs || 0} Pending
              </p>
              <p className="text-[11px] text-stone-500">Awaiting approval</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4">
          <div className="aspect-4/3 rounded-xl overflow-hidden border border-stone-200 bg-stone-100">
            <img
              src={FARM_IMAGES.eggs}
              alt="Fresh organic brown eggs ready for wholesale market"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Choose Buyer Cards & Sell Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-4">
          <h2 className="text-lg font-bold text-stone-900">Choose Buyer</h2>
          <div className="space-y-4">
            {activeBuyers.map((buyer) => {
              const isSelected = buyer.id === selectedBuyer.id;
              return (
                <div
                  key={buyer.id}
                  className={`bg-white rounded-2xl border p-5 transition-colors ${
                    isSelected ? 'border-amber-700 ring-1 ring-amber-700' : 'border-stone-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-stone-900">{buyer.name}</h3>
                        <span aria-hidden="true" className="text-stone-300">·</span>
                        <span className="flex items-center gap-1 text-xs font-mono font-semibold text-amber-800">
                          <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
                          {buyer.rating.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 mt-1 font-mono">
                        <span>{buyer.tradesCount} trades</span>
                        <span aria-hidden="true">·</span>
                        <span>{buyer.successRate}% success rate</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          Min: {buyer.minQty} / Max: {buyer.maxQty} Eggs
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-3 sm:pt-0 border-stone-100">
                      <div className="text-left sm:text-right">
                        <p className="text-xs text-stone-500">Buyer Rate</p>
                        <p className="text-lg font-bold text-emerald-800 font-mono tabular-nums">
                          PKR {buyer.ratePerEgg} / egg
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSelectedBuyerId(buyer.id)}
                        className={`px-4 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                          isSelected
                            ? 'bg-amber-700 text-white'
                            : 'bg-stone-900 hover:bg-stone-800 text-white'
                        }`}
                      >
                        {isSelected ? 'Selected' : 'Sell Now'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sell Request Form */}
        <div className="lg:col-span-5">
          <div className="bg-white border border-stone-200 rounded-2xl p-6 space-y-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Submit Egg Sale Order
              </p>
              <h3 className="text-xl font-bold text-stone-900 mt-0.5">
                Selling to {selectedBuyer.name}
              </h3>
              <p className="text-xs text-stone-500 mt-0.5 font-mono">
                Locked Rate: PKR {selectedBuyer.ratePerEgg} per egg · Limits: {selectedBuyer.minQty}–{selectedBuyer.maxQty} eggs
              </p>
            </div>

            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                {errorMsg}
              </div>
            )}

            {successMsg && (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleSellSubmit} className="space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <label className="font-semibold text-stone-700">Egg Quantity to Sell</label>
                  <span className="text-stone-500 font-mono">
                    Balance: {userAccount.eggsBalance} Eggs
                  </span>
                </div>
                <input
                  type="number"
                  min={selectedBuyer.minQty}
                  max={selectedBuyer.maxQty}
                  required
                  value={eggQuantity}
                  onChange={(e) => setEggQuantity(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono focus:outline-none focus:border-amber-700"
                />
              </div>

              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-600">Calculated Payout</span>
                <span className="text-lg font-bold text-emerald-800 font-mono tabular-nums">
                  PKR {calculatedPayout.toLocaleString()}
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Payout Method
                </label>
                <select
                  value={payoutMethod}
                  onChange={(e) => setPayoutMethod(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm focus:outline-none focus:border-amber-700"
                >
                  <option value="Farmer Wallet Balance">Credit to Available Balance (PKR)</option>
                  <option value="JazzCash">JazzCash</option>
                  <option value="EasyPaisa">EasyPaisa</option>
                  <option value="SadaPay">SadaPay</option>
                  <option value="UPaisa">UPaisa</option>
                  <option value="Bank Account">Bank Account</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Payout Account Details (Account Title & Number)
                </label>
                <input
                  type="text"
                  required
                  value={payoutAccountDetails}
                  onChange={(e) => setPayoutAccountDetails(e.target.value)}
                  placeholder="e.g. Muhammad Ali - 03001234567"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono focus:outline-none focus:border-amber-700"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 px-5 rounded-xl bg-amber-700 hover:bg-amber-800 disabled:opacity-60 text-white font-semibold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                {submitting ? 'Submitting Sell Request...' : 'Submit Egg Sale Request'}
              </button>
            </form>

            <p className="text-[11px] text-stone-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>Egg balance is reduced and payout is recorded only after Admin approves the sale.</span>
            </p>
          </div>
        </div>
      </div>

      {/* Recent Egg Sale Requests */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6">
        <h3 className="text-base font-bold text-stone-900 mb-4">Your Egg Sale History</h3>
        {eggSales.length === 0 ? (
          <p className="text-xs text-stone-500 py-4">No egg sale transactions submitted yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500">
                  <th className="py-2.5 pr-4 font-semibold">Date</th>
                  <th className="py-2.5 pr-4 font-semibold">Buyer</th>
                  <th className="py-2.5 pr-4 font-semibold text-right">Eggs</th>
                  <th className="py-2.5 pr-4 font-semibold text-right">Rate</th>
                  <th className="py-2.5 pr-4 font-semibold text-right">Total Payout</th>
                  <th className="py-2.5 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                {eggSales.map((sale) => (
                  <tr key={sale.id}>
                    <td className="py-3 pr-4 text-stone-600">{sale.createdAt.slice(0, 10)}</td>
                    <td className="py-3 pr-4 font-sans font-medium text-stone-900">{sale.buyerName}</td>
                    <td className="py-3 pr-4 text-right text-stone-900">{sale.eggQuantity}</td>
                    <td className="py-3 pr-4 text-right text-stone-600">PKR {sale.ratePerEgg}</td>
                    <td className="py-3 pr-4 text-right font-semibold text-emerald-800">
                      PKR {sale.totalPayout.toLocaleString()}
                    </td>
                    <td className="py-3 text-right font-sans font-semibold">
                      <span
                        className={
                          sale.status === 'Approved'
                            ? 'text-emerald-800'
                            : sale.status === 'Rejected'
                            ? 'text-red-700'
                            : 'text-amber-800'
                        }
                      >
                        {sale.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
