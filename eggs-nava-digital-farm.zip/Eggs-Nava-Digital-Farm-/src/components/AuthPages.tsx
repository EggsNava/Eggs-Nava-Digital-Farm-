import React, { useState } from 'react';
import { Eye, EyeOff, MessageCircle, Radio, ShieldCheck, ArrowLeft, CheckCircle2, AlertCircle, UserCheck } from 'lucide-react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider, OWNER_ADMIN_EMAIL, handleFirestoreError, OperationType } from '../firebase';
import { PlatformSettings, UserAccount, UserPublic } from '../types';
import { FARM_IMAGES } from '../constants/assets';

interface AuthPagesProps {
  mode: 'login' | 'register' | 'welcome';
  setMode: (mode: 'home' | 'login' | 'register' | 'welcome' | 'dashboard' | 'admin') => void;
  settings: PlatformSettings;
  initialReferrer: string;
  currentUserAccount: UserAccount | null;
}

export const AuthPages: React.FC<AuthPagesProps> = ({
  mode,
  setMode,
  settings,
  initialReferrer,
  currentUserAccount,
}) => {
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [referredBy, setReferredBy] = useState(initialReferrer || '');
  const [showPassword, setShowPassword] = useState(false);
  const [saveDevice, setSaveDevice] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const sanitizeUsername = (val: string) => {
    // Username must not allow spaces
    return val.replace(/\s+/g, '').replace(/[^a-zA-Z0-9_-]/g, '');
  };

  const toSyntheticEmail = (cleanUser: string) => {
    return `${cleanUser.toLowerCase()}@eggsnava.digital`;
  };

  const createProfileDocsIfMissing = async (
    uid: string,
    cleanUsername: string,
    userPhone: string,
    userEmail: string,
    refCode: string,
    isOwnerAdmin: boolean
  ) => {
    const now = new Date().toISOString();
    const userDocRef = doc(db, 'users', uid);
    const publicDocRef = doc(db, 'users_public', uid);

    let existingSnap;
    try {
      existingSnap = await getDoc(userDocRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${uid}`);
    }

    if (!existingSnap || !existingSnap.exists()) {
      const safeUsername = cleanUsername.slice(0, 40) || `farmer_${uid.slice(0, 6)}`;
      const safePhone = userPhone.trim().length >= 7 ? userPhone.trim().slice(0, 25) : '03000000000';
      const safeRef = (refCode || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);

      const newAccount: UserAccount = {
        uid,
        username: safeUsername,
        phone: safePhone,
        email: userEmail.slice(0, 120),
        referralCode: safeUsername,
        referredBy: safeRef,
        role: isOwnerAdmin ? 'admin' : 'user',
        status: 'active',
        verifiedFarmer: true,
        availableBalance: 0,
        eggsBalance: 0,
        activeHens: 0,
        totalHens: 0,
        pendingHens: 0,
        pendingEggs: 0,
        totalEggsProfit: 0,
        referralBonus: 0,
        totalInvestment: 0,
        totalWithdraw: 0,
        totalReferrals: 0,
        activeTeam: 0,
        lastHarvestAt: '',
        createdAt: now,
        updatedAt: now,
      };

      const newPublic: UserPublic = {
        uid,
        username: safeUsername,
        referralCode: safeUsername,
        referredBy: safeRef,
        verifiedFarmer: true,
        status: 'active',
        createdAt: now,
      };

      try {
        await setDoc(userDocRef, newAccount);
        await setDoc(publicDocRef, newPublic);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${uid}`);
      }
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanUser = sanitizeUsername(username);
    if (cleanUser.length < 3) {
      setErrorMsg('Username must be at least 3 characters without spaces (letters, numbers, _ or -).');
      return;
    }
    if (phone.trim().length < 7) {
      setErrorMsg('Please enter a valid Phone Number (at least 7 digits).');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    setLoading(true);
    try {
      await setPersistence(auth, saveDevice ? browserLocalPersistence : browserSessionPersistence);
      const email = toSyntheticEmail(cleanUser);
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      const isOwner =
        cred.user.email?.toLowerCase() === OWNER_ADMIN_EMAIL.toLowerCase() &&
        cred.user.emailVerified;

      await createProfileDocsIfMissing(cred.user.uid, cleanUser, phone, email, referredBy, isOwner);
      setMode('welcome');
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/email-already-in-use') {
        setErrorMsg('This username is already registered. Please choose another username or Login.');
      } else if (code === 'auth/operation-not-allowed') {
        setErrorMsg(
          'Username/Password sign-up requires Email/Password provider enabled in Firebase Console, or click "Continue with Google" below for instant verified registration.'
        );
      } else {
        setErrorMsg(err?.message || 'Registration failed. Please check your details or use Google Sign-In.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanInput = username.trim();
    if (!cleanInput || !password) {
      setErrorMsg('Please enter your Username and Password.');
      return;
    }

    setLoading(true);
    try {
      await setPersistence(auth, saveDevice ? browserLocalPersistence : browserSessionPersistence);
      const email = cleanInput.includes('@') ? cleanInput : toSyntheticEmail(sanitizeUsername(cleanInput));
      await signInWithEmailAndPassword(auth, email, password);
      setMode('dashboard');
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/invalid-credential' || code === 'auth/user-not-found' || code === 'auth/wrong-password') {
        setErrorMsg('Invalid username or password. Please verify your credentials.');
      } else if (code === 'auth/operation-not-allowed') {
        setErrorMsg('Please sign in with Google below or enable Email/Password in your Firebase Console.');
      } else {
        setErrorMsg(err?.message || 'Login failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async (isRegisterFlow: boolean) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await setPersistence(auth, saveDevice ? browserLocalPersistence : browserSessionPersistence);
      const cred = await signInWithPopup(auth, googleProvider);
      const user = cred.user;
      const isOwner =
        user.email?.toLowerCase() === OWNER_ADMIN_EMAIL.toLowerCase() &&
        user.emailVerified;

      const rawName = username.trim()
        ? sanitizeUsername(username)
        : sanitizeUsername(user.displayName || user.email?.split('@')[0] || `farmer_${user.uid.slice(0, 6)}`);
      const finalUsername = rawName.length >= 3 ? rawName : `farmer_${user.uid.slice(0, 6)}`;
      const finalPhone = phone.trim().length >= 7 ? phone.trim() : '03000000000';

      await createProfileDocsIfMissing(
        user.uid,
        finalUsername,
        finalPhone,
        user.email || toSyntheticEmail(finalUsername),
        referredBy,
        isOwner
      );

      if (isRegisterFlow) {
        setMode('welcome');
      } else {
        setMode('dashboard');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Google authentication was cancelled or failed.');
    } finally {
      setLoading(false);
    }
  };

  if (mode === 'welcome') {
    return (
      <div className="min-h-screen bg-[#F9F8F6] flex flex-col justify-center items-center px-4 py-12">
        <div className="max-w-xl w-full bg-white border border-stone-200 rounded-2xl p-8 md:p-10 shadow-sm text-center">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto mb-6 text-emerald-800">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <p className="text-xs font-medium tracking-wider uppercase text-emerald-800 mb-2">
            Registration Complete · Verified Farmer Profile Created
          </p>
          <h1 className="text-3xl md:text-4xl font-bold text-stone-900 mb-2">Welcome</h1>
          <h2 className="text-lg font-semibold text-amber-800 mb-6">
            Welcome to EGGS NAVA DIGITAL FARM
          </h2>

          {currentUserAccount && (
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 mb-6 text-left flex items-center justify-between">
              <div>
                <p className="text-xs text-stone-500">Registered Farmer Username</p>
                <p className="text-base font-semibold text-stone-900 font-mono">@{currentUserAccount.username}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-stone-500">Account Status</p>
                <p className="text-sm font-medium text-emerald-800">Verified Farmer</p>
              </div>
            </div>
          )}

          {/* Urdu Welcome Message */}
          <div
            dir="rtl"
            className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-6 mb-8 text-right leading-relaxed text-stone-800"
          >
            <p className="text-lg font-semibold text-stone-900 mb-2">
              ایگز ناوا ڈیجیٹل فارم (EGGS NAVA DIGITAL FARM) میں خوش آمدید!
            </p>
            <p className="text-base text-stone-700 leading-8">
              آپ کا فارمر اکاؤنٹ کامیابی کے ساتھ بن چکا ہے۔ فارم کی روزانہ اپڈیٹس، انڈوں کے تازہ مارکیٹ ریٹس، اور اہم معلومات حاصل کرنے کے لیے ابھی ہمارے آفیشل واٹس ایپ گروپ اور واٹس ایپ چینل کو جوائن کریں۔
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            <a
              href={settings.whatsappGroup || 'https://chat.whatsapp.com/'}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-sm transition-colors whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4 shrink-0" />
              <span>WhatsApp Group</span>
            </a>

            <a
              href={settings.whatsappChannel || 'https://whatsapp.com/channel/'}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold text-sm transition-colors whitespace-nowrap"
            >
              <Radio className="w-4 h-4 shrink-0" />
              <span>WhatsApp Channel</span>
            </a>
          </div>

          <button
            onClick={() => setMode('dashboard')}
            className="w-full py-3.5 px-6 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-sm transition-colors"
          >
            Continue to Farmer Dashboard
          </button>
        </div>
      </div>
    );
  }

  const isRegister = mode === 'register';

  return (
    <div className="min-h-screen bg-[#F9F8F6] flex flex-col">
      {/* Minimal Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-white">
        <button
          onClick={() => setMode('home')}
          className="text-lg font-bold tracking-tight text-stone-900 font-display text-left"
        >
          EGGS NAVA DIGITAL FARM
        </button>
        <button
          onClick={() => setMode('home')}
          className="flex items-center gap-2 text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Farm Home</span>
        </button>
      </header>

      <div className="flex-1 max-w-6xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center px-6 py-10">
        {/* Left Visual Column */}
        <div className="lg:col-span-6 space-y-6">
          <div className="relative rounded-2xl overflow-hidden border border-stone-200 bg-stone-900 aspect-4/3">
            <img
              src={FARM_IMAGES.hen}
              alt="Healthy brown Rhode Island Red laying hen on green pasture"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6 md:p-8">
              <p className="text-xs text-amber-300 font-medium mb-1">
                Naturally Raised · Verified Digital Flock Management
              </p>
              <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight">
                {isRegister ? 'Join the farming family' : 'Welcome back to your digital poultry farm'}
              </h2>
              <p className="text-sm text-stone-200 mt-2 max-w-md">
                Manage real free-range brown hen packages, collect daily egg harvests, and sell directly to verified wholesale buyers.
              </p>
            </div>
          </div>

          {/* Official WhatsApp Support Links */}
          <div className="bg-white border border-stone-200 rounded-xl p-5">
            <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3">
              Official Farmer Support & Updates
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <a
                href={settings.whatsappAdmin || 'https://wa.me/'}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-stone-200 hover:border-emerald-700 hover:bg-emerald-50/40 text-stone-800 text-xs font-semibold transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>WhatsApp Admin</span>
              </a>
              <a
                href={settings.whatsappChannel || 'https://whatsapp.com/channel/'}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-stone-200 hover:border-amber-700 hover:bg-amber-50/40 text-stone-800 text-xs font-semibold transition-colors whitespace-nowrap"
              >
                <Radio className="w-4 h-4 text-amber-700 shrink-0" />
                <span>WhatsApp Channel</span>
              </a>
            </div>
          </div>
        </div>

        {/* Right Form Column */}
        <div className="lg:col-span-6">
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-sm">
            <div className="mb-6">
              <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider mb-1">
                {isRegister ? 'New Farmer Onboarding' : 'Farmer Portal Access'}
              </p>
              <h1 className="text-2xl md:text-3xl font-bold text-stone-900">
                {isRegister ? 'Join the farming family' : 'Login to EGGS NAVA'}
              </h1>
              <p className="text-sm text-stone-600 mt-1">
                {isRegister
                  ? 'Create your unique farmer account. Username cannot contain spaces.'
                  : 'Enter your registered farmer username and password to access your flock.'}
              </p>
            </div>

            {errorMsg && (
              <div className="mb-5 p-4 rounded-xl bg-red-50 border border-red-200 flex items-start gap-3 text-red-900 text-xs leading-relaxed">
                <AlertCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={isRegister ? handleRegisterSubmit : handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Username {isRegister && <span className="text-stone-400 font-normal">(No spaces allowed)</span>}
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(isRegister ? sanitizeUsername(e.target.value) : e.target.value.replace(/\s+/g, ''))}
                  placeholder="e.g. ahmad_farms"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-none focus:border-amber-700 font-mono"
                />
              </div>

              {isRegister && (
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 03001234567"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-none focus:border-amber-700 font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={isRegister ? 'Create a strong password (min 6 chars)' : 'Enter your password'}
                    className="w-full pl-3.5 pr-20 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-none focus:border-amber-700"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 px-2 py-1 text-xs font-medium text-stone-600 hover:text-stone-900 flex items-center gap-1"
                  >
                    {showPassword ? (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Hide</span>
                      </>
                    ) : (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>Show</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {isRegister && (
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Referred By <span className="text-stone-400 font-normal">(Optional referral username)</span>
                  </label>
                  <input
                    type="text"
                    value={referredBy}
                    onChange={(e) => setReferredBy(sanitizeUsername(e.target.value))}
                    placeholder="Referral username (if invited)"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-stone-50 text-stone-900 text-sm focus:outline-none focus:border-amber-700 font-mono"
                  />
                </div>
              )}

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={saveDevice}
                    onChange={(e) => setSaveDevice(e.target.checked)}
                    className="w-4 h-4 rounded border-stone-300 text-amber-700 focus:ring-amber-700"
                  />
                  <span className="text-xs text-stone-700 font-medium">
                    Save this account on this device
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-5 rounded-xl bg-amber-700 hover:bg-amber-800 disabled:opacity-60 text-white font-semibold text-sm transition-colors cursor-pointer"
              >
                {loading
                  ? 'Connecting to EGGS NAVA Farm...'
                  : isRegister
                  ? 'Create Account'
                  : 'Login to Dashboard'}
              </button>
            </form>

            <div className="my-5 flex items-center gap-3">
              <div className="h-px bg-stone-200 flex-1" />
              <span className="text-xs text-stone-400 font-medium">OR VERIFIED GOOGLE ACCOUNT</span>
              <div className="h-px bg-stone-200 flex-1" />
            </div>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleGoogleSignIn(isRegister)}
              className="w-full py-2.5 px-4 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-emerald-700" />
              <span>{isRegister ? 'Fast Register with Google Account' : 'Continue with Google Account (Farmer / Admin)'}</span>
            </button>

            <div className="mt-6 pt-5 border-t border-stone-200 text-center">
              {isRegister ? (
                <p className="text-xs text-stone-600">
                  Already registered?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg(null);
                      setMode('login');
                    }}
                    className="font-semibold text-amber-800 hover:underline"
                  >
                    Login
                  </button>
                </p>
              ) : (
                <p className="text-xs text-stone-600">
                  New to EGGS NAVA DIGITAL FARM?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg(null);
                      setMode('register');
                    }}
                    className="font-semibold text-amber-800 hover:underline"
                  >
                    Create Account
                  </button>
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
