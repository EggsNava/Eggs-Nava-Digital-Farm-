import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  Search,
  Plus,
  Trash2,
  Save,
  ShieldCheck,
  ArrowLeft,
} from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  AuditLog,
  DepositRequest,
  EggBuyer,
  EggSale,
  FarmPlan,
  HenOrder,
  PlatformSettings,
  TransactionRecord,
  UserAccount,
  WithdrawalRequest,
} from '../types';

interface AdminPanelProps {
  plans: FarmPlan[];
  buyers: EggBuyer[];
  settings: PlatformSettings;
  onExitAdmin: () => void;
}

type AdminSection =
  | 'approvals'
  | 'plans'
  | 'users'
  | 'balance-control'
  | 'buyers'
  | 'payment-settings'
  | 'whatsapp-settings'
  | 'audit-logs';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  plans,
  buyers,
  settings,
  onExitAdmin,
}) => {
  const [section, setSection] = useState<AdminSection>('approvals');
  const [statusBanner, setStatusBanner] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [savingPlan, setSavingPlan] = useState(false);

  // Admin real-time collections
  const [allUsers, setAllUsers] = useState<UserAccount[]>([]);
  const [allDeposits, setAllDeposits] = useState<DepositRequest[]>([]);
  const [allHenOrders, setAllHenOrders] = useState<HenOrder[]>([]);
  const [allEggSales, setAllEggSales] = useState<EggSale[]>([]);
  const [allWithdrawals, setAllWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // User search
  const [userSearch, setUserSearch] = useState('');

  // Editable Plan State — initialized from live Firestore plans prop
  const [editingPlan, setEditingPlan] = useState<FarmPlan>(() => {
    const first = plans.find((p) => p.id === 'golden_hen') || plans[0];
    return (
      first || {
        id: 'golden_hen',
        name: 'Golden Hen',
        description:
          'Naturally raised Rhode Island Red laying hen with consistent daily brown egg production and full pasture care.',
        henPrice: 500,
        dailyEggs: 1,
        referReward: 120,
        durationDays: 120,
        active: true,
        imageKey: 'hen',
        updatedAt: new Date().toISOString(),
      }
    );
  });

  // Editable Buyer State
  const [editingBuyer, setEditingBuyer] = useState<EggBuyer>({
    id: `buyer_${Date.now()}`,
    name: '',
    rating: 4.9,
    tradesCount: 100,
    ratePerEgg: 28,
    successRate: 99.0,
    minQty: 5,
    maxQty: 5000,
    active: true,
    updatedAt: new Date().toISOString(),
  });

  // Balance Control Form State
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [adjustField, setAdjustField] = useState<
    'availableBalance' | 'eggsBalance' | 'activeHens' | 'referralBonus' | 'totalEggsProfit'
  >('availableBalance');
  const [deltaAmount, setDeltaAmount] = useState<string>('500');
  const [adjustReason, setAdjustReason] = useState<string>('');

  // Settings Form State
  const [settingsForm, setSettingsForm] = useState<PlatformSettings>(settings);

  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  // Keep editingPlan synchronized if the plan is updated in Firestore
  useEffect(() => {
    const matched = plans.find((p) => p.id === editingPlan.id);
    if (matched && matched.updatedAt !== editingPlan.updatedAt) {
      setEditingPlan(matched);
    }
  }, [plans]);

  useEffect(() => {
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        const list: UserAccount[] = [];
        snap.forEach((d) => list.push(d.data() as UserAccount));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAllUsers(list);
        if (!selectedUserId && list.length > 0) {
          setSelectedUserId(list[0].uid);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );

    const unsubDeps = onSnapshot(
      collection(db, 'deposits'),
      (snap) => {
        const list: DepositRequest[] = [];
        snap.forEach((d) => list.push(d.data() as DepositRequest));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAllDeposits(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'deposits')
    );

    const unsubHens = onSnapshot(
      collection(db, 'hen_orders'),
      (snap) => {
        const list: HenOrder[] = [];
        snap.forEach((d) => list.push(d.data() as HenOrder));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAllHenOrders(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'hen_orders')
    );

    const unsubSales = onSnapshot(
      collection(db, 'egg_sales'),
      (snap) => {
        const list: EggSale[] = [];
        snap.forEach((d) => list.push(d.data() as EggSale));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAllEggSales(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'egg_sales')
    );

    const unsubWds = onSnapshot(
      collection(db, 'withdrawals'),
      (snap) => {
        const list: WithdrawalRequest[] = [];
        snap.forEach((d) => list.push(d.data() as WithdrawalRequest));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAllWithdrawals(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'withdrawals')
    );

    const unsubLogs = onSnapshot(
      collection(db, 'audit_logs'),
      (snap) => {
        const list: AuditLog[] = [];
        snap.forEach((d) => list.push(d.data() as AuditLog));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setAuditLogs(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'audit_logs')
    );

    return () => {
      unsubUsers();
      unsubDeps();
      unsubHens();
      unsubSales();
      unsubWds();
      unsubLogs();
    };
  }, []);

  const flashBanner = (msg: string) => {
    setErrorBanner(null);
    setStatusBanner(msg);
    setTimeout(() => setStatusBanner(null), 5000);
  };

  // --- PLAN MANAGEMENT ---
  const handleSavePackageInFirebase = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorBanner(null);
    const now = new Date().toISOString();
    const cleanId = editingPlan.id
      .trim()
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_-]/g, '')
      .slice(0, 128);

    if (!cleanId || editingPlan.name.trim().length < 2) {
      setErrorBanner('Plan ID and Plan Name (minimum 2 characters) are required.');
      return;
    }

    const planDoc: FarmPlan = {
      id: cleanId,
      name: editingPlan.name.trim().slice(0, 80),
      description: editingPlan.description.trim().slice(0, 500),
      henPrice: Math.max(0, Number(editingPlan.henPrice) || 0),
      dailyEggs: Math.max(0, Number(editingPlan.dailyEggs) || 0),
      referReward: Math.max(0, Number(editingPlan.referReward) || 0),
      durationDays: Math.max(1, Number(editingPlan.durationDays) || 120),
      active: Boolean(editingPlan.active),
      imageKey: editingPlan.imageKey || 'hen',
      updatedAt: now,
    };

    setSavingPlan(true);
    try {
      await setDoc(doc(db, 'plans', cleanId), planDoc);
      setEditingPlan(planDoc);
      flashBanner(
        `Package "${planDoc.name}" (PKR ${planDoc.henPrice} | Daily Eggs: ${planDoc.dailyEggs} | Refer: PKR ${planDoc.referReward} | Days: ${planDoc.durationDays}) saved to Firebase Firestore!`
      );
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `plans/${cleanId}`);
      setErrorBanner(err?.message || 'Failed to save package to Firebase Firestore.');
    } finally {
      setSavingPlan(false);
    }
  };

  const handleTogglePlanActive = async (plan: FarmPlan) => {
    const now = new Date().toISOString();
    const updatedPlan: FarmPlan = {
      ...plan,
      active: !plan.active,
      updatedAt: now,
    };
    try {
      await setDoc(doc(db, 'plans', plan.id), updatedPlan);
      if (editingPlan.id === plan.id) {
        setEditingPlan(updatedPlan);
      }
      flashBanner(`Package "${plan.name}" is now ${updatedPlan.active ? 'Active' : 'Inactive'} in Firebase.`);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `plans/${plan.id}`);
      setErrorBanner(err?.message || 'Failed to update plan status.');
    }
  };

  const handleDeletePlan = async (planId: string) => {
    try {
      await deleteDoc(doc(db, 'plans', planId));
      flashBanner(`Plan "${planId}" removed from Firebase.`);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, `plans/${planId}`);
      setErrorBanner(err?.message || 'Failed to delete plan.');
    }
  };

  // --- BUYER MANAGEMENT ---
  const handleSaveBuyer = async (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date().toISOString();
    const cleanId = editingBuyer.id
      .trim()
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_-]/g, '')
      .slice(0, 128);

    if (!cleanId || editingBuyer.name.trim().length < 2) return;

    const buyerDoc: EggBuyer = {
      id: cleanId,
      name: editingBuyer.name.trim().slice(0, 80),
      rating: Math.min(5, Math.max(0, Number(editingBuyer.rating) || 4.9)),
      tradesCount: Math.max(0, Number(editingBuyer.tradesCount) || 0),
      ratePerEgg: Math.max(0, Number(editingBuyer.ratePerEgg) || 28),
      successRate: Math.min(100, Math.max(0, Number(editingBuyer.successRate) || 99)),
      minQty: Math.max(1, Number(editingBuyer.minQty) || 1),
      maxQty: Math.max(Number(editingBuyer.minQty) || 1, Number(editingBuyer.maxQty) || 1000),
      active: Boolean(editingBuyer.active),
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'buyers', cleanId), buyerDoc);
      flashBanner(`Egg Buyer "${buyerDoc.name}" saved to Firebase!`);
      setEditingBuyer({
        id: `buyer_${Date.now()}`,
        name: '',
        rating: 4.9,
        tradesCount: 100,
        ratePerEgg: 28,
        successRate: 99,
        minQty: 5,
        maxQty: 5000,
        active: true,
        updatedAt: now,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `buyers/${cleanId}`);
    }
  };

  const handleDeleteBuyer = async (buyerId: string) => {
    try {
      await deleteDoc(doc(db, 'buyers', buyerId));
      flashBanner('Buyer removed from Firebase.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `buyers/${buyerId}`);
    }
  };

  // --- TRANSACTION APPROVALS ---
  const handleDepositDecision = async (dep: DepositRequest, decision: 'Approved' | 'Rejected') => {
    if (dep.status !== 'Pending') return;
    const now = new Date().toISOString();
    const targetUser = allUsers.find((u) => u.uid === dep.userId);

    try {
      await updateDoc(doc(db, 'deposits', dep.id), {
        status: decision,
        updatedAt: now,
      });

      if (decision === 'Approved' && targetUser) {
        await updateDoc(doc(db, 'users', targetUser.uid), {
          availableBalance: (targetUser.availableBalance || 0) + dep.amount,
          updatedAt: now,
        });
      }

      const txId = `tx_dep_${Date.now()}`;
      const txDoc: TransactionRecord = {
        id: txId,
        userId: dep.userId,
        username: dep.username,
        type: 'Deposit',
        amount: dep.amount,
        unit: 'PKR',
        status: decision,
        referenceId: dep.referenceId,
        description: `Deposit ${decision} by Admin (${dep.paymentMethod})`,
        createdAt: now,
      };
      await setDoc(doc(db, 'transactions', txId), txDoc);
      flashBanner(`Deposit ${dep.id} marked as ${decision}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `deposits/${dep.id}`);
    }
  };

  const handleHenOrderDecision = async (ord: HenOrder, decision: 'Approved' | 'Rejected') => {
    if (ord.status !== 'Pending') return;
    const now = new Date().toISOString();
    const startDate = now;
    const endDate = new Date(Date.now() + ord.durationDays * 24 * 60 * 60 * 1000).toISOString();
    const targetUser = allUsers.find((u) => u.uid === ord.userId);

    try {
      await updateDoc(doc(db, 'hen_orders', ord.id), {
        status: decision,
        startDate: decision === 'Approved' ? startDate : '',
        endDate: decision === 'Approved' ? endDate : '',
        updatedAt: now,
      });

      if (targetUser) {
        const nextPendingHens = Math.max(0, (targetUser.pendingHens || 0) - ord.quantity);
        if (decision === 'Approved') {
          await updateDoc(doc(db, 'users', targetUser.uid), {
            activeHens: (targetUser.activeHens || 0) + ord.quantity,
            totalHens: (targetUser.totalHens || 0) + ord.quantity,
            pendingHens: nextPendingHens,
            totalInvestment: (targetUser.totalInvestment || 0) + ord.totalAmount,
            updatedAt: now,
          });

          // Credit Referral Reward if the user was referred by an active farmer
          if (targetUser.referredBy && settingsForm.referralEnabled) {
            const referrer = allUsers.find(
              (u) =>
                u.referralCode.toLowerCase() === targetUser.referredBy.toLowerCase() ||
                u.username.toLowerCase() === targetUser.referredBy.toLowerCase()
            );
            if (referrer) {
              const rewardAmount = (ord.referReward || settingsForm.defaultReferReward) * ord.quantity;
              await updateDoc(doc(db, 'users', referrer.uid), {
                availableBalance: (referrer.availableBalance || 0) + rewardAmount,
                referralBonus: (referrer.referralBonus || 0) + rewardAmount,
                totalReferrals: (referrer.totalReferrals || 0) + 1,
                activeTeam: (referrer.activeTeam || 0) + 1,
                updatedAt: now,
              });

              const refTxId = `tx_ref_${Date.now()}`;
              const refTxDoc: TransactionRecord = {
                id: refTxId,
                userId: referrer.uid,
                username: referrer.username,
                type: 'Referral Reward',
                amount: rewardAmount,
                unit: 'PKR',
                status: 'Approved',
                referenceId: ord.id,
                description: `Referral bonus from @${targetUser.username} purchasing ${ord.quantity}x ${ord.planName}`,
                createdAt: now,
              };
              await setDoc(doc(db, 'transactions', refTxId), refTxDoc);
            }
          }
        } else {
          await updateDoc(doc(db, 'users', targetUser.uid), {
            pendingHens: nextPendingHens,
            updatedAt: now,
          });
        }
      }

      const txId = `tx_hen_${Date.now()}`;
      const txDoc: TransactionRecord = {
        id: txId,
        userId: ord.userId,
        username: ord.username,
        type: 'Hen Purchase',
        amount: ord.totalAmount,
        unit: 'PKR',
        status: decision,
        referenceId: ord.referenceId,
        description: `${ord.quantity}x ${ord.planName} ${decision} by Admin`,
        createdAt: now,
      };
      await setDoc(doc(db, 'transactions', txId), txDoc);
      flashBanner(`Hen Order ${ord.id} marked as ${decision}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `hen_orders/${ord.id}`);
    }
  };

  const handleEggSaleDecision = async (sale: EggSale, decision: 'Approved' | 'Rejected') => {
    if (sale.status !== 'Pending') return;
    const now = new Date().toISOString();
    const targetUser = allUsers.find((u) => u.uid === sale.userId);

    try {
      await updateDoc(doc(db, 'egg_sales', sale.id), {
        status: decision,
        updatedAt: now,
      });

      if (targetUser) {
        const nextPendingEggs = Math.max(0, (targetUser.pendingEggs || 0) - sale.eggQuantity);
        if (decision === 'Approved') {
          await updateDoc(doc(db, 'users', targetUser.uid), {
            eggsBalance: Math.max(0, (targetUser.eggsBalance || 0) - sale.eggQuantity),
            pendingEggs: nextPendingEggs,
            availableBalance: (targetUser.availableBalance || 0) + sale.totalPayout,
            updatedAt: now,
          });
        } else {
          await updateDoc(doc(db, 'users', targetUser.uid), {
            pendingEggs: nextPendingEggs,
            updatedAt: now,
          });
        }
      }

      const txId = `tx_sale_${Date.now()}`;
      const txDoc: TransactionRecord = {
        id: txId,
        userId: sale.userId,
        username: sale.username,
        type: 'Egg Sale',
        amount: sale.totalPayout,
        unit: 'PKR',
        status: decision,
        referenceId: sale.id,
        description: `Egg Sale (${sale.eggQuantity} Eggs) ${decision} by Admin`,
        createdAt: now,
      };
      await setDoc(doc(db, 'transactions', txId), txDoc);
      flashBanner(`Egg Sale ${sale.id} marked as ${decision}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `egg_sales/${sale.id}`);
    }
  };

  const handleWithdrawalDecision = async (wd: WithdrawalRequest, decision: 'Approved' | 'Rejected') => {
    if (wd.status !== 'Pending') return;
    const now = new Date().toISOString();
    const targetUser = allUsers.find((u) => u.uid === wd.userId);

    try {
      await updateDoc(doc(db, 'withdrawals', wd.id), {
        status: decision,
        updatedAt: now,
      });

      if (decision === 'Approved' && targetUser) {
        await updateDoc(doc(db, 'users', targetUser.uid), {
          availableBalance: Math.max(0, (targetUser.availableBalance || 0) - wd.amount),
          totalWithdraw: (targetUser.totalWithdraw || 0) + wd.amount,
          updatedAt: now,
        });
      }

      const txId = `tx_wd_${Date.now()}`;
      const txDoc: TransactionRecord = {
        id: txId,
        userId: wd.userId,
        username: wd.username,
        type: 'Withdrawal',
        amount: wd.amount,
        unit: 'PKR',
        status: decision,
        referenceId: wd.id,
        description: `Withdrawal (${wd.payoutMethod}) ${decision} by Admin`,
        createdAt: now,
      };
      await setDoc(doc(db, 'transactions', txId), txDoc);
      flashBanner(`Withdrawal ${wd.id} marked as ${decision}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `withdrawals/${wd.id}`);
    }
  };

  // --- USER STATUS TOGGLE ---
  const handleToggleUserStatus = async (u: UserAccount) => {
    const nextStatus = u.status === 'active' ? 'deactivated' : 'active';
    const now = new Date().toISOString();
    try {
      await updateDoc(doc(db, 'users', u.uid), {
        status: nextStatus,
        updatedAt: now,
      });
      await updateDoc(doc(db, 'users_public', u.uid), {
        status: nextStatus,
      });
      flashBanner(`User @${u.username} status updated to ${nextStatus}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${u.uid}`);
    }
  };

  // --- MANUAL BALANCE & ASSET CONTROL + AUDIT LOG ---
  const handleManualAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetUser = allUsers.find((u) => u.uid === selectedUserId);
    const numDelta = Number(deltaAmount);
    if (!targetUser || isNaN(numDelta) || numDelta === 0 || adjustReason.trim().length < 2) {
      return;
    }

    const now = new Date().toISOString();
    const currentVal = Number(targetUser[adjustField] || 0);
    const nextVal = Math.max(0, currentVal + numDelta);

    const updatePayload: Record<string, any> = {
      [adjustField]: nextVal,
      updatedAt: now,
    };

    if (adjustField === 'activeHens' && numDelta > 0) {
      updatePayload.totalHens = (targetUser.totalHens || 0) + numDelta;
    }

    const logId = `audit_${Date.now()}`;
    const auditDoc: AuditLog = {
      id: logId,
      targetUserId: targetUser.uid,
      targetUsername: targetUser.username,
      adjustmentType: adjustField,
      deltaAmount: numDelta,
      reason: adjustReason.trim().slice(0, 300),
      adminEmail: auth.currentUser?.email || 'owner@eggsnava.digital',
      createdAt: now,
    };

    const txId = `tx_adj_${Date.now()}`;
    const txDoc: TransactionRecord = {
      id: txId,
      userId: targetUser.uid,
      username: targetUser.username,
      type: 'Admin Adjustment',
      amount: numDelta,
      unit: adjustField === 'eggsBalance' || adjustField === 'totalEggsProfit' ? 'EGGS' : adjustField === 'activeHens' ? 'HENS' : 'PKR',
      status: 'Approved',
      referenceId: logId,
      description: `Admin adjustment (${adjustField}): ${adjustReason.trim().slice(0, 180)}`,
      createdAt: now,
    };

    try {
      await updateDoc(doc(db, 'users', targetUser.uid), updatePayload);
      await setDoc(doc(db, 'audit_logs', logId), auditDoc);
      await setDoc(doc(db, 'transactions', txId), txDoc);
      setAdjustReason('');
      flashBanner(
        `Adjusted ${adjustField} by ${numDelta > 0 ? `+${numDelta}` : numDelta} for @${targetUser.username} and recorded audit log.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${targetUser.uid}`);
    }
  };

  // --- SAVE GLOBAL SETTINGS ---
  const handleSaveGlobalSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date().toISOString();
    const updatedSettings: PlatformSettings = {
      ...settingsForm,
      defaultReferReward: Number(settingsForm.defaultReferReward) || 0,
      updatedAt: now,
    };
    try {
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      flashBanner('Platform Settings saved to Firebase Firestore and synced live to all users!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings/global');
    }
  };

  const filteredUsers = allUsers.filter(
    (u) =>
      u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.phone.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.uid.toLowerCase().includes(userSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-stone-900 flex flex-col">
      {/* Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-stone-900 text-white px-6 py-4 border-b border-stone-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <span className="text-lg font-bold tracking-tight font-display whitespace-nowrap">
            EGGS NAVA DIGITAL FARM — OWNER ADMIN
          </span>

          <nav className="hidden xl:flex items-center gap-5 text-xs font-medium text-stone-300">
            <button onClick={() => setSection('approvals')} className={`hover:text-white cursor-pointer ${section === 'approvals' ? 'text-amber-400 font-bold' : ''}`}>
              Approvals
            </button>
            <button onClick={() => setSection('plans')} className={`hover:text-white cursor-pointer ${section === 'plans' ? 'text-amber-400 font-bold' : ''}`}>
              Plan Management
            </button>
            <button onClick={() => setSection('users')} className={`hover:text-white cursor-pointer ${section === 'users' ? 'text-amber-400 font-bold' : ''}`}>
              Users
            </button>
            <button onClick={() => setSection('balance-control')} className={`hover:text-white cursor-pointer ${section === 'balance-control' ? 'text-amber-400 font-bold' : ''}`}>
              Balance Control
            </button>
            <button onClick={() => setSection('payment-settings')} className={`hover:text-white cursor-pointer ${section === 'payment-settings' ? 'text-amber-400 font-bold' : ''}`}>
              Payment Settings
            </button>
            <button onClick={() => setSection('whatsapp-settings')} className={`hover:text-white cursor-pointer ${section === 'whatsapp-settings' ? 'text-amber-400 font-bold' : ''}`}>
              WhatsApp & Rules
            </button>
          </nav>

          <button
            onClick={onExitAdmin}
            className="px-4 py-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Farmer View</span>
          </button>
        </div>
      </header>

      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-6 flex-1">
        {/* Sub-navigation bar for all viewports */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-200/80 p-1.5 rounded-xl">
          {[
            { id: 'approvals', label: 'Transaction Approvals' },
            { id: 'plans', label: 'Plan Management' },
            { id: 'users', label: 'User Management' },
            { id: 'balance-control', label: 'Balance Control' },
            { id: 'buyers', label: 'Egg Buyers' },
            { id: 'payment-settings', label: 'Payment Settings' },
            { id: 'whatsapp-settings', label: 'WhatsApp & Platform' },
            { id: 'audit-logs', label: 'Audit Logs' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSection(tab.id as AdminSection)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                section === tab.id
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {statusBanner && (
          <div className="p-4 rounded-xl bg-emerald-800 text-white text-xs font-semibold flex items-center gap-2.5 shadow-xs">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{statusBanner}</span>
          </div>
        )}

        {errorBanner && (
          <div className="p-4 rounded-xl bg-red-700 text-white text-xs font-semibold flex items-center gap-2.5 shadow-xs">
            <XCircle className="w-4 h-4 shrink-0" />
            <span>{errorBanner}</span>
          </div>
        )}

        {/* 1. TRANSACTION APPROVALS */}
        {section === 'approvals' && (
          <div className="space-y-8">
            {/* Hen Orders */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-stone-900 mb-4">
                Hen Orders ({allHenOrders.filter((o) => o.status === 'Pending').length} Pending)
              </h2>
              {allHenOrders.length === 0 ? (
                <p className="text-xs text-stone-500">No hen purchase requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2 pr-3">Farmer</th>
                        <th className="py-2 pr-3">Plan & Qty</th>
                        <th className="py-2 pr-3">Gateway & Ref ID</th>
                        <th className="py-2 pr-3 text-right">Total PKR</th>
                        <th className="py-2 pr-3">Status</th>
                        <th className="py-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {allHenOrders.map((ord) => (
                        <tr key={ord.id}>
                          <td className="py-3 pr-3 font-semibold text-stone-900">@{ord.username}</td>
                          <td className="py-3 pr-3 font-sans">
                            {ord.quantity}x {ord.planName} ({ord.totalDailyEggs} eggs/day)
                          </td>
                          <td className="py-3 pr-3">
                            {ord.paymentMethod} · Ref: <strong>{ord.referenceId}</strong>
                            {ord.proofNote && <div className="text-[11px] text-stone-500">{ord.proofNote}</div>}
                          </td>
                          <td className="py-3 pr-3 text-right font-bold text-amber-800">
                            PKR {ord.totalAmount.toLocaleString()}
                          </td>
                          <td className="py-3 pr-3 font-sans font-semibold">{ord.status}</td>
                          <td className="py-3 text-right">
                            {ord.status === 'Pending' ? (
                              <div className="flex items-center justify-end gap-2 font-sans">
                                <button
                                  onClick={() => handleHenOrderDecision(ord, 'Approved')}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleHenOrderDecision(ord, 'Rejected')}
                                  className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-stone-400">Processed</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Deposits */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-stone-900 mb-4">
                Deposits ({allDeposits.filter((d) => d.status === 'Pending').length} Pending)
              </h2>
              {allDeposits.length === 0 ? (
                <p className="text-xs text-stone-500">No deposit requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2 pr-3">Farmer</th>
                        <th className="py-2 pr-3">Method & Ref ID</th>
                        <th className="py-2 pr-3 text-right">Amount</th>
                        <th className="py-2 pr-3">Status</th>
                        <th className="py-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {allDeposits.map((dep) => (
                        <tr key={dep.id}>
                          <td className="py-3 pr-3 font-semibold text-stone-900">@{dep.username}</td>
                          <td className="py-3 pr-3">
                            {dep.paymentMethod} · Ref: <strong>{dep.referenceId}</strong>
                            {dep.proofNote && <div className="text-[11px] text-stone-500">{dep.proofNote}</div>}
                          </td>
                          <td className="py-3 pr-3 text-right font-bold text-emerald-800">
                            PKR {dep.amount.toLocaleString()}
                          </td>
                          <td className="py-3 pr-3 font-sans font-semibold">{dep.status}</td>
                          <td className="py-3 text-right">
                            {dep.status === 'Pending' ? (
                              <div className="flex items-center justify-end gap-2 font-sans">
                                <button
                                  onClick={() => handleDepositDecision(dep, 'Approved')}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleDepositDecision(dep, 'Rejected')}
                                  className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-stone-400">Processed</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Egg Sales */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-stone-900 mb-4">
                Egg Sales ({allEggSales.filter((s) => s.status === 'Pending').length} Pending)
              </h2>
              {allEggSales.length === 0 ? (
                <p className="text-xs text-stone-500">No egg sale requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2 pr-3">Farmer</th>
                        <th className="py-2 pr-3">Buyer & Eggs</th>
                        <th className="py-2 pr-3">Payout Account</th>
                        <th className="py-2 pr-3 text-right">Payout PKR</th>
                        <th className="py-2 pr-3">Status</th>
                        <th className="py-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {allEggSales.map((sale) => (
                        <tr key={sale.id}>
                          <td className="py-3 pr-3 font-semibold text-stone-900">@{sale.username}</td>
                          <td className="py-3 pr-3 font-sans">
                            {sale.eggQuantity} Eggs to {sale.buyerName} (@ PKR {sale.ratePerEgg})
                          </td>
                          <td className="py-3 pr-3">
                            {sale.payoutMethod}: {sale.payoutAccountDetails}
                          </td>
                          <td className="py-3 pr-3 text-right font-bold text-emerald-800">
                            PKR {sale.totalPayout.toLocaleString()}
                          </td>
                          <td className="py-3 pr-3 font-sans font-semibold">{sale.status}</td>
                          <td className="py-3 text-right">
                            {sale.status === 'Pending' ? (
                              <div className="flex items-center justify-end gap-2 font-sans">
                                <button
                                  onClick={() => handleEggSaleDecision(sale, 'Approved')}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleEggSaleDecision(sale, 'Rejected')}
                                  className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-stone-400">Processed</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Withdrawals */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-stone-900 mb-4">
                Withdrawals ({allWithdrawals.filter((w) => w.status === 'Pending').length} Pending)
              </h2>
              {allWithdrawals.length === 0 ? (
                <p className="text-xs text-stone-500">No withdrawal requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2 pr-3">Farmer</th>
                        <th className="py-2 pr-3">Payout Method & Account</th>
                        <th className="py-2 pr-3 text-right">Amount</th>
                        <th className="py-2 pr-3">Status</th>
                        <th className="py-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                      {allWithdrawals.map((wd) => (
                        <tr key={wd.id}>
                          <td className="py-3 pr-3 font-semibold text-stone-900">@{wd.username}</td>
                          <td className="py-3 pr-3">
                            {wd.payoutMethod}: <strong>{wd.accountDetails}</strong>
                          </td>
                          <td className="py-3 pr-3 text-right font-bold text-amber-800">
                            PKR {wd.amount.toLocaleString()}
                          </td>
                          <td className="py-3 pr-3 font-sans font-semibold">{wd.status}</td>
                          <td className="py-3 text-right">
                            {wd.status === 'Pending' ? (
                              <div className="flex items-center justify-end gap-2 font-sans">
                                <button
                                  onClick={() => handleWithdrawalDecision(wd, 'Approved')}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleWithdrawalDecision(wd, 'Rejected')}
                                  className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-stone-400">Processed</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 2. PLAN MANAGEMENT ("Save Package in Firebase") */}
        {section === 'plans' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 space-y-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                  Create or Edit Package
                </p>
                <h2 className="text-xl font-bold text-stone-900 mt-0.5">Plan Management</h2>
                <p className="text-xs text-stone-500 mt-1">
                  Select an existing plan or create a new package. Saving writes directly to Firebase Firestore and updates the customer Buy Hens page immediately.
                </p>
              </div>

              {/* Quick Plan Selector Dropdown */}
              <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 text-xs">
                <label className="block font-semibold text-stone-700 mb-1.5">
                  Select Existing Plan to Edit
                </label>
                <select
                  value={plans.some((p) => p.id === editingPlan.id) ? editingPlan.id : '__custom__'}
                  onChange={(e) => {
                    const found = plans.find((p) => p.id === e.target.value);
                    if (found) {
                      setEditingPlan({ ...found });
                    }
                  }}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white font-medium text-stone-900"
                >
                  {plans.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.id}) — PKR {p.henPrice} | {p.dailyEggs} Egg/day
                    </option>
                  ))}
                  {!plans.some((p) => p.id === editingPlan.id) && (
                    <option value="__custom__">New Custom Plan ({editingPlan.id})</option>
                  )}
                </select>
              </div>

              <form onSubmit={handleSavePackageInFirebase} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Plan ID (Unique Slug)
                  </label>
                  <input
                    type="text"
                    required
                    value={editingPlan.id}
                    onChange={(e) => setEditingPlan({ ...editingPlan, id: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Plan Name</label>
                  <input
                    type="text"
                    required
                    value={editingPlan.name}
                    onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Hen Price (PKR)
                    </label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingPlan.henPrice}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, henPrice: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Daily Eggs</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingPlan.dailyEggs}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, dailyEggs: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Refer Reward (PKR)
                    </label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingPlan.referReward}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, referReward: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Duration (Days)
                    </label>
                    <input
                      type="number"
                      min={1}
                      required
                      value={editingPlan.durationDays}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, durationDays: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Description</label>
                  <textarea
                    rows={2}
                    value={editingPlan.description}
                    onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 items-center">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Photograph</label>
                    <select
                      value={editingPlan.imageKey}
                      onChange={(e) => setEditingPlan({ ...editingPlan, imageKey: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white"
                    >
                      <option value="hen">Brown Laying Hen</option>
                      <option value="pasture">Pasture Flock</option>
                      <option value="eggs">Fresh Brown Eggs</option>
                      <option value="hero">Sunlit Farm Hero</option>
                    </select>
                  </div>

                  <label className="flex items-center gap-2 pt-5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingPlan.active}
                      onChange={(e) => setEditingPlan({ ...editingPlan, active: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <span className="font-semibold text-stone-800">Plan Active</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={savingPlan}
                  className="w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 disabled:opacity-60 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{savingPlan ? 'Saving to Firebase...' : 'Save Package in Firebase'}</span>
                </button>
              </form>
            </div>

            <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-stone-900">
                  Live Packages in Firebase ({plans.length})
                </h3>
                <button
                  type="button"
                  onClick={() =>
                    setEditingPlan({
                      id: `plan_${Date.now()}`,
                      name: 'New Farm Package',
                      description: 'Naturally raised brown hen package.',
                      henPrice: 600,
                      dailyEggs: 1,
                      referReward: 120,
                      durationDays: 120,
                      active: true,
                      imageKey: 'hen',
                      updatedAt: new Date().toISOString(),
                    })
                  }
                  className="px-3 py-1.5 rounded-lg border border-stone-300 hover:bg-stone-50 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Blank Package</span>
                </button>
              </div>

              <div className="space-y-3">
                {plans.map((p) => {
                  const isCurrentlyEditing = p.id === editingPlan.id;
                  return (
                    <div
                      key={p.id}
                      className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                        isCurrentlyEditing
                          ? 'border-amber-700 bg-amber-50/30'
                          : 'border-stone-200 bg-white'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-stone-900">{p.name}</span>
                          <span className="text-xs font-mono text-stone-500">({p.id})</span>
                          <span
                            className={`text-xs font-semibold ${
                              p.active ? 'text-emerald-800' : 'text-red-700'
                            }`}
                          >
                            · {p.active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <p className="text-xs font-mono text-stone-600 mt-1">
                          Price: PKR {p.henPrice} · Daily Eggs: {p.dailyEggs} · Refer: PKR{' '}
                          {p.referReward} · Days: {p.durationDays}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => setEditingPlan({ ...p })}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                            isCurrentlyEditing
                              ? 'bg-amber-700 text-white'
                              : 'bg-stone-900 text-white hover:bg-stone-800'
                          }`}
                        >
                          {isCurrentlyEditing ? 'Editing' : 'Edit Plan'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleTogglePlanActive(p)}
                          className="px-2.5 py-1.5 rounded-lg border border-stone-300 hover:bg-stone-50 text-xs font-semibold text-stone-700 cursor-pointer"
                        >
                          {p.active ? 'Deactivate' : 'Activate'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePlan(p.id)}
                          className="p-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 cursor-pointer"
                          title="Delete Plan"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 3. USER MANAGEMENT */}
        {section === 'users' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-stone-900">
                  User Management ({allUsers.length} Registered Farmers)
                </h2>
                <p className="text-xs text-stone-500">
                  View farmer balances, hens, eggs, referrals, and activate/deactivate accounts.
                </p>
              </div>
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search username, phone, UID..."
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-500">
                    <th className="py-2.5 pr-3">Username</th>
                    <th className="py-2.5 pr-3">Phone</th>
                    <th className="py-2.5 pr-3">Referred By</th>
                    <th className="py-2.5 pr-3 text-right">Balance (PKR)</th>
                    <th className="py-2.5 pr-3 text-right">Eggs</th>
                    <th className="py-2.5 pr-3 text-right">Active Hens</th>
                    <th className="py-2.5 pr-3">Status</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                  {filteredUsers.map((u) => (
                    <tr key={u.uid}>
                      <td className="py-3 pr-3 font-bold text-stone-900">@{u.username}</td>
                      <td className="py-3 pr-3 text-stone-600">{u.phone}</td>
                      <td className="py-3 pr-3 text-stone-500">{u.referredBy || '-'}</td>
                      <td className="py-3 pr-3 text-right font-semibold text-stone-900">
                        {u.availableBalance.toLocaleString()}
                      </td>
                      <td className="py-3 pr-3 text-right text-amber-800">{u.eggsBalance}</td>
                      <td className="py-3 pr-3 text-right text-emerald-800">{u.activeHens}</td>
                      <td className="py-3 pr-3 font-sans font-semibold">
                        <span className={u.status === 'active' ? 'text-emerald-800' : 'text-red-700'}>
                          {u.status}
                        </span>
                      </td>
                      <td className="py-3 text-right font-sans">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setSelectedUserId(u.uid);
                              setSection('balance-control');
                            }}
                            className="px-2.5 py-1 rounded bg-amber-700 text-white font-semibold cursor-pointer"
                          >
                            Adjust Balance
                          </button>
                          <button
                            onClick={() => handleToggleUserStatus(u)}
                            className="px-2.5 py-1 rounded border border-stone-300 hover:bg-stone-100 text-stone-800 font-semibold cursor-pointer"
                          >
                            {u.status === 'active' ? 'Deactivate' : 'Activate'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 4. ADMIN BALANCE CONTROL */}
        {section === 'balance-control' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 space-y-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                  Audited Balance & Asset Adjustment
                </p>
                <h2 className="text-xl font-bold text-stone-900 mt-0.5">
                  Admin Balance Control
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  Increase or decrease user balance, eggs, active hens, referral rewards, or profit. Every change creates an immutable audit record.
                </p>
              </div>

              <form onSubmit={handleManualAdjustment} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Select Farmer</label>
                  <select
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg border border-stone-300 bg-white font-mono"
                  >
                    {allUsers.map((u) => (
                      <option key={u.uid} value={u.uid}>
                        @{u.username} — Bal: PKR {u.availableBalance} | Eggs: {u.eggsBalance} | Hens: {u.activeHens}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Target Account Metric
                  </label>
                  <select
                    value={adjustField}
                    onChange={(e) => setAdjustField(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-lg border border-stone-300 bg-white"
                  >
                    <option value="availableBalance">Available Balance (PKR)</option>
                    <option value="eggsBalance">Eggs Balance (Eggs)</option>
                    <option value="activeHens">Active Hens (Flock Count)</option>
                    <option value="referralBonus">Referral Bonus (PKR)</option>
                    <option value="totalEggsProfit">Total Eggs Profit (Eggs)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Adjustment Delta (Use positive number to increase, negative e.g. -200 to decrease)
                  </label>
                  <input
                    type="number"
                    required
                    value={deltaAmount}
                    onChange={(e) => setDeltaAmount(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg border border-stone-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Audit Reason (Required for transparency)
                  </label>
                  <input
                    type="text"
                    required
                    value={adjustReason}
                    onChange={(e) => setAdjustReason(e.target.value)}
                    placeholder="e.g. Manual bank deposit verification bonus"
                    className="w-full px-3 py-2.5 rounded-lg border border-stone-300"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs cursor-pointer"
                >
                  Apply Adjustment & Record Audit Log
                </button>
              </form>
            </div>

            <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-stone-900 mb-4">Recent Audit Records</h3>
              {auditLogs.length === 0 ? (
                <p className="text-xs text-stone-500">No manual adjustments logged yet.</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 text-xs">
                      <div className="flex justify-between font-mono">
                        <span className="font-bold text-stone-900">@{log.targetUsername}</span>
                        <span className={log.deltaAmount >= 0 ? 'text-emerald-800 font-bold' : 'text-red-700 font-bold'}>
                          {log.adjustmentType}: {log.deltaAmount >= 0 ? `+${log.deltaAmount}` : log.deltaAmount}
                        </span>
                      </div>
                      <p className="text-stone-600 mt-1">Reason: {log.reason}</p>
                      <p className="text-[11px] text-stone-400 font-mono mt-1">
                        Admin: {log.adminEmail} · {log.createdAt.replace('T', ' ').slice(0, 16)}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 5. EGG BUYERS MANAGEMENT */}
        {section === 'buyers' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 space-y-4">
              <h2 className="text-xl font-bold text-stone-900">Manage Egg Rapid Buyers</h2>
              <form onSubmit={handleSaveBuyer} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Buyer ID</label>
                  <input
                    type="text"
                    required
                    value={editingBuyer.id}
                    onChange={(e) => setEditingBuyer({ ...editingBuyer, id: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Buyer Name</label>
                  <input
                    type="text"
                    required
                    value={editingBuyer.name}
                    onChange={(e) => setEditingBuyer({ ...editingBuyer, name: e.target.value })}
                    placeholder="e.g. Al-Madina Egg Traders"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Rate per Egg (PKR)</label>
                    <input
                      type="number"
                      required
                      value={editingBuyer.ratePerEgg}
                      onChange={(e) => setEditingBuyer({ ...editingBuyer, ratePerEgg: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Rating (0-5)</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      value={editingBuyer.rating}
                      onChange={(e) => setEditingBuyer({ ...editingBuyer, rating: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Min Egg Qty</label>
                    <input
                      type="number"
                      required
                      value={editingBuyer.minQty}
                      onChange={(e) => setEditingBuyer({ ...editingBuyer, minQty: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Max Egg Qty</label>
                    <input
                      type="number"
                      required
                      value={editingBuyer.maxQty}
                      onChange={(e) => setEditingBuyer({ ...editingBuyer, maxQty: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs cursor-pointer"
                >
                  Save Egg Buyer in Firebase
                </button>
              </form>
            </div>

            <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 space-y-3">
              <h3 className="text-lg font-bold text-stone-900">Active Egg Buyers ({buyers.length})</h3>
              {buyers.map((b) => (
                <div key={b.id} className="p-4 rounded-xl border border-stone-200 flex items-center justify-between">
                  <div className="text-xs">
                    <p className="font-bold text-sm text-stone-900">{b.name}</p>
                    <p className="font-mono text-stone-600 mt-0.5">
                      Rate: PKR {b.ratePerEgg}/egg · Min: {b.minQty} · Max: {b.maxQty} · Rating: {b.rating}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setEditingBuyer(b)}
                      className="px-3 py-1.5 rounded-lg bg-stone-900 text-white text-xs font-semibold cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteBuyer(b.id)}
                      className="p-1.5 rounded-lg border border-red-200 text-red-700 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. ADMIN PAYMENT SETTINGS */}
        {section === 'payment-settings' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 max-w-4xl">
            <h2 className="text-xl font-bold text-stone-900 mb-1">Admin Payment Gateway Settings</h2>
            <p className="text-xs text-stone-500 mb-6">
              Configure Bank Account, JazzCash, EasyPaisa, SadaPay, UPaisa, and instructions. Saved directly to Firebase.
            </p>

            <form onSubmit={handleSaveGlobalSettings} className="space-y-5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={settingsForm.bankName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, bankName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Bank Account Title</label>
                  <input
                    type="text"
                    value={settingsForm.bankAccountTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, bankAccountTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Bank Account Number</label>
                  <input
                    type="text"
                    value={settingsForm.bankAccountNumber}
                    onChange={(e) => setSettingsForm({ ...settingsForm, bankAccountNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Bank IBAN</label>
                  <input
                    type="text"
                    value={settingsForm.bankIban}
                    onChange={(e) => setSettingsForm({ ...settingsForm, bankIban: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-stone-200">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">JazzCash Account Title</label>
                  <input
                    type="text"
                    value={settingsForm.jazzCashTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, jazzCashTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">JazzCash Number</label>
                  <input
                    type="text"
                    value={settingsForm.jazzCashNumber}
                    onChange={(e) => setSettingsForm({ ...settingsForm, jazzCashNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">EasyPaisa Account Title</label>
                  <input
                    type="text"
                    value={settingsForm.easyPaisaTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, easyPaisaTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">EasyPaisa Number</label>
                  <input
                    type="text"
                    value={settingsForm.easyPaisaNumber}
                    onChange={(e) => setSettingsForm({ ...settingsForm, easyPaisaNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">SadaPay Account Title</label>
                  <input
                    type="text"
                    value={settingsForm.sadaPayTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, sadaPayTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">SadaPay Number / Details</label>
                  <input
                    type="text"
                    value={settingsForm.sadaPayNumber}
                    onChange={(e) => setSettingsForm({ ...settingsForm, sadaPayNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">UPaisa Account Title</label>
                  <input
                    type="text"
                    value={settingsForm.uPaisaTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, uPaisaTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">UPaisa Number / Details</label>
                  <input
                    type="text"
                    value={settingsForm.uPaisaNumber}
                    onChange={(e) => setSettingsForm({ ...settingsForm, uPaisaNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t border-stone-200">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Hen Purchase Payment Instructions
                  </label>
                  <textarea
                    rows={2}
                    value={settingsForm.paymentInstructions}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, paymentInstructions: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Deposit Instructions
                  </label>
                  <textarea
                    rows={2}
                    value={settingsForm.depositInstructions}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, depositInstructions: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Withdrawal Instructions
                  </label>
                  <textarea
                    rows={2}
                    value={settingsForm.withdrawalInstructions}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, withdrawalInstructions: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs cursor-pointer"
              >
                Save Payment Settings in Firebase
              </button>
            </form>
          </div>
        )}

        {/* 7. WHATSAPP, REFERRAL & PLATFORM SETTINGS */}
        {section === 'whatsapp-settings' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 max-w-4xl">
            <h2 className="text-xl font-bold text-stone-900 mb-1">
              WhatsApp Links, Referral Rules & Compliance Settings
            </h2>
            <p className="text-xs text-stone-500 mb-6">
              All links and platform settings are stored in Firebase and immediately updated across the Welcome Page, Homepage, and Farmer Dashboard.
            </p>

            <form onSubmit={handleSaveGlobalSettings} className="space-y-5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">WhatsApp Admin Link</label>
                  <input
                    type="url"
                    value={settingsForm.whatsappAdmin}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsappAdmin: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">WhatsApp Owner Link</label>
                  <input
                    type="url"
                    value={settingsForm.whatsappOwner}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsappOwner: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">WhatsApp Group Link</label>
                  <input
                    type="url"
                    value={settingsForm.whatsappGroup}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsappGroup: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">WhatsApp Channel Link</label>
                  <input
                    type="url"
                    value={settingsForm.whatsappChannel}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsappChannel: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-200">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Default Referral Reward (PKR)
                  </label>
                  <input
                    type="number"
                    value={settingsForm.defaultReferReward}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, defaultReferReward: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <label className="flex items-center gap-2 pt-5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settingsForm.referralEnabled}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, referralEnabled: e.target.checked })
                    }
                    className="w-4 h-4"
                  />
                  <span className="font-semibold text-stone-800">Referral Rewards Active</span>
                </label>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Referral Rules</label>
                <textarea
                  rows={2}
                  value={settingsForm.referralRules}
                  onChange={(e) => setSettingsForm({ ...settingsForm, referralRules: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300"
                />
              </div>

              <div className="pt-4 border-t border-stone-200 space-y-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settingsForm.fbrSecpEnabled}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, fbrSecpEnabled: e.target.checked })
                    }
                    className="w-4 h-4"
                  />
                  <span className="font-semibold text-stone-800">
                    Display Official FBR / SECP Registration Section (Only enable if legitimate registration details are entered below)
                  </span>
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      FBR Registration Info
                    </label>
                    <input
                      type="text"
                      value={settingsForm.fbrRegistrationInfo}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, fbrRegistrationInfo: e.target.value })
                      }
                      placeholder="Leave blank if not applicable"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      SECP Registration Info
                    </label>
                    <input
                      type="text"
                      value={settingsForm.secpRegistrationInfo}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, secpRegistrationInfo: e.target.value })
                      }
                      placeholder="Leave blank if not applicable"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs cursor-pointer"
              >
                Save WhatsApp & Platform Settings in Firebase
              </button>
            </form>
          </div>
        )}

        {/* 8. FULL AUDIT LOGS */}
        {section === 'audit-logs' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6">
            <h2 className="text-xl font-bold text-stone-900 mb-4">
              Complete Admin Balance & Asset Audit Trail ({auditLogs.length})
            </h2>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-stone-500">No manual balance adjustments recorded yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500">
                      <th className="py-2.5 pr-3">Date / Time</th>
                      <th className="py-2.5 pr-3">Target User</th>
                      <th className="py-2.5 pr-3">Field Adjusted</th>
                      <th className="py-2.5 pr-3 text-right">Delta</th>
                      <th className="py-2.5 pr-3">Reason</th>
                      <th className="py-2.5">Admin</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-mono tabular-nums">
                    {auditLogs.map((log) => (
                      <tr key={log.id}>
                        <td className="py-3 pr-3 text-stone-600">
                          {log.createdAt.replace('T', ' ').slice(0, 16)}
                        </td>
                        <td className="py-3 pr-3 font-bold text-stone-900">@{log.targetUsername}</td>
                        <td className="py-3 pr-3">{log.adjustmentType}</td>
                        <td
                          className={`py-3 pr-3 text-right font-bold ${
                            log.deltaAmount >= 0 ? 'text-emerald-800' : 'text-red-700'
                          }`}
                        >
                          {log.deltaAmount >= 0 ? `+${log.deltaAmount}` : log.deltaAmount}
                        </td>
                        <td className="py-3 pr-3 font-sans text-stone-700">{log.reason}</td>
                        <td className="py-3 text-stone-500">{log.adminEmail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
