import React, { useState } from 'react';
import { Minus, Plus, CheckCircle2, ArrowLeft, ShieldCheck, Copy, Check } from 'lucide-react';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { FarmPlan, PlatformSettings, UserAccount, HenOrder, TransactionRecord } from '../types';
import { getPlanImage } from '../constants/assets';

interface FarmMarketProps {
  plans: FarmPlan[];
  settings: PlatformSettings;
  userAccount: UserAccount;
  onSuccessOrder: () => void;
}

type PaymentGateway = 'Bank Account' | 'JazzCash' | 'EasyPaisa' | 'SadaPay' | 'UPaisa';

export const FarmMarket: React.FC<FarmMarketProps> = ({
  plans,
  settings,
  userAccount,
  onSuccessOrder,
}) => {
  const activePlans = plans.filter((p) => p.active);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedPlanId, setSelectedPlanId] = useState<string>(activePlans[0]?.id || 'golden_hen');
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedGateway, setSelectedGateway] = useState<PaymentGateway>('JazzCash');
  const [referenceId, setReferenceId] = useState('');
  const [proofNote, setProofNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submittedOrder, setSubmittedOrder] = useState<HenOrder | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedAccount, setCopiedAccount] = useState(false);

  // Always resolve the selected plan live from Firestore plans prop so Admin edits immediately reflect
  const selectedPlan: FarmPlan | undefined =
    activePlans.find((p) => p.id === selectedPlanId) || activePlans[0] || plans[0];

  if (!selectedPlan) {
    return (
      <div className="bg-white border border-stone-200 rounded-2xl p-8 text-center">
        <p className="text-sm font-semibold text-stone-800">
          Loading Farm Packages from Firebase Firestore...
        </p>
      </div>
    );
  }

  const subtotal = quantity * selectedPlan.henPrice;
  const gatewayFee = 0;
  const totalPayment = subtotal + gatewayFee;

  const getGatewayDetails = (gateway: PaymentGateway) => {
    switch (gateway) {
      case 'Bank Account':
        return {
          title: settings.bankAccountTitle,
          number: settings.bankAccountNumber,
          extra: `Bank: ${settings.bankName} · IBAN: ${settings.bankIban}`,
        };
      case 'JazzCash':
        return {
          title: settings.jazzCashTitle,
          number: settings.jazzCashNumber,
          extra: 'JazzCash Mobile Account',
        };
      case 'EasyPaisa':
        return {
          title: settings.easyPaisaTitle,
          number: settings.easyPaisaNumber,
          extra: 'EasyPaisa Mobile Account',
        };
      case 'SadaPay':
        return {
          title: settings.sadaPayTitle,
          number: settings.sadaPayNumber,
          extra: 'SadaPay Wallet / IBAN',
        };
      case 'UPaisa':
        return {
          title: settings.uPaisaTitle,
          number: settings.uPaisaNumber,
          extra: 'UPaisa Mobile Wallet',
        };
    }
  };

  const handleCopyAccount = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (referenceId.trim().length < 2) {
      setErrorMsg('Please enter your valid payment Transaction / Reference ID.');
      return;
    }

    setSubmitting(true);
    const now = new Date().toISOString();
    const orderId = `hen_${Date.now()}_${userAccount.uid.slice(0, 6)}`;
    const txId = `tx_${Date.now()}_${userAccount.uid.slice(0, 6)}`;

    const orderDoc: HenOrder = {
      id: orderId,
      userId: userAccount.uid,
      username: userAccount.username,
      planId: selectedPlan.id,
      planName: selectedPlan.name,
      henPrice: selectedPlan.henPrice,
      quantity,
      dailyEggsPerHen: selectedPlan.dailyEggs,
      totalDailyEggs: quantity * selectedPlan.dailyEggs,
      durationDays: selectedPlan.durationDays,
      referReward: selectedPlan.referReward,
      totalAmount: totalPayment,
      paymentMethod: selectedGateway,
      referenceId: referenceId.trim().slice(0, 120),
      proofNote: proofNote.trim().slice(0, 500),
      status: 'Pending',
      startDate: '',
      endDate: '',
      lastHarvestDate: '',
      eggsAccumulated: 0,
      createdAt: now,
      updatedAt: now,
    };

    const txDoc: TransactionRecord = {
      id: txId,
      userId: userAccount.uid,
      username: userAccount.username,
      type: 'Hen Purchase',
      amount: totalPayment,
      unit: 'PKR',
      status: 'Pending',
      referenceId: referenceId.trim().slice(0, 120),
      description: `${quantity}x ${selectedPlan.name} (${selectedGateway}) — Pending Admin Approval`,
      createdAt: now,
    };

    try {
      await setDoc(doc(db, 'hen_orders', orderId), orderDoc);
      await setDoc(doc(db, 'transactions', txId), txDoc);
      await updateDoc(doc(db, 'users', userAccount.uid), {
        pendingHens: (userAccount.pendingHens || 0) + quantity,
        updatedAt: now,
      });
      setSubmittedOrder(orderDoc);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `hen_orders/${orderId}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (submittedOrder) {
    return (
      <div className="bg-white border border-stone-200 rounded-2xl p-8 max-w-2xl mx-auto text-center">
        <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto mb-5 text-amber-800">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <p className="text-xs font-semibold uppercase tracking-wider text-amber-800 mb-1">
          Payment Request Submitted · Status: Pending
        </p>
        <h2 className="text-2xl font-bold text-stone-900 mb-2">
          Hen Order Awaiting Admin Verification
        </h2>
        <p className="text-sm text-stone-600 mb-6 max-w-md mx-auto">
          Your request for <span className="font-semibold text-stone-900">{submittedOrder.quantity}x {submittedOrder.planName}</span> (PKR {submittedOrder.totalAmount.toLocaleString()}) has been logged with Reference ID <span className="font-mono font-semibold text-stone-900">{submittedOrder.referenceId}</span>. Hens are added to your active flock immediately after Admin approves your transaction.
        </p>
        <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 mb-6 text-left text-xs space-y-2">
          <div className="flex justify-between">
            <span className="text-stone-500">Order ID</span>
            <span className="font-mono font-semibold text-stone-900">{submittedOrder.id}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Selected Package</span>
            <span className="font-semibold text-stone-900">{submittedOrder.planName} ({submittedOrder.quantity} Hens)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Daily Egg Yield (upon approval)</span>
            <span className="font-mono font-semibold text-emerald-800">{submittedOrder.totalDailyEggs} Eggs / day</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Verification Status</span>
            <span className="font-semibold text-amber-800">Pending Manual Verification</span>
          </div>
        </div>
        <button
          onClick={() => {
            setSubmittedOrder(null);
            setStep(1);
            setReferenceId('');
            setProofNote('');
            onSuccessOrder();
          }}
          className="px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs transition-colors cursor-pointer"
        >
          Return to Farmer Dashboard
        </button>
      </div>
    );
  }

  const currentGatewayInfo = getGatewayDetails(selectedGateway);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-amber-800 mb-1">
          EGGS NAVA DIGITAL FARM MARKET
        </p>
        <h1 className="text-2xl md:text-3xl font-bold text-stone-900">
          Complete your farm investment.
        </h1>
        <p className="text-sm text-stone-600 mt-1">
          Choose a farm card, set your hen quantity and submit a secure payment request.
        </p>

        {/* 3-Step Flow Indicator */}
        <div className="mt-6 pt-6 border-t border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={() => setStep(1)}
            className={`text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
              step === 1
                ? 'border-amber-700 bg-amber-50/50'
                : 'border-stone-200 bg-stone-50 hover:bg-stone-100/70'
            }`}
          >
            <p className="text-xs font-mono font-semibold text-amber-800">Step 01</p>
            <p className="text-sm font-bold text-stone-900 mt-0.5">Select Farm Plan</p>
          </button>

          <button
            type="button"
            onClick={() => setStep(2)}
            className={`text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
              step === 2
                ? 'border-amber-700 bg-amber-50/50'
                : 'border-stone-200 bg-stone-50 hover:bg-stone-100/70'
            }`}
          >
            <p className="text-xs font-mono font-semibold text-amber-800">Step 02</p>
            <p className="text-sm font-bold text-stone-900 mt-0.5">Hen Quantity</p>
          </button>

          <button
            type="button"
            onClick={() => setStep(3)}
            className={`text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
              step === 3
                ? 'border-amber-700 bg-amber-50/50'
                : 'border-stone-200 bg-stone-50 hover:bg-stone-100/70'
            }`}
          >
            <p className="text-xs font-mono font-semibold text-amber-800">Step 03</p>
            <p className="text-sm font-bold text-stone-900 mt-0.5">Payment Method & Submit</p>
          </button>
        </div>
      </div>

      {/* STEP 01: SELECT FARM CARD */}
      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {activePlans.map((plan) => {
            const isSelected = plan.id === selectedPlan.id;
            return (
              <div
                key={plan.id}
                className={`bg-white rounded-2xl border overflow-hidden flex flex-col justify-between transition-colors ${
                  isSelected ? 'border-amber-700 ring-1 ring-amber-700' : 'border-stone-200'
                }`}
              >
                <div>
                  <div className="aspect-4/3 bg-stone-100 overflow-hidden">
                    <img
                      src={getPlanImage(plan.imageKey)}
                      alt={plan.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-stone-900">{plan.name}</h3>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">{plan.description}</p>

                    <div className="mt-5 pt-4 border-t border-stone-200 space-y-2.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-stone-500">Hen price:</span>
                        <span className="font-bold text-amber-800 font-mono tabular-nums">
                          PKR {plan.henPrice.toLocaleString()} per hen
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Daily Eggs:</span>
                        <span className="font-bold text-emerald-800 font-mono tabular-nums">
                          {plan.dailyEggs}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Refer Reward:</span>
                        <span className="font-bold text-stone-900 font-mono tabular-nums">
                          PKR {plan.referReward.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Days:</span>
                        <span className="font-bold text-stone-900 font-mono tabular-nums">
                          {plan.durationDays}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-6 pb-6">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPlanId(plan.id);
                      setStep(2);
                    }}
                    className="w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Select {plan.name} & Set Quantity
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* STEP 02: HEN QUANTITY PAGE */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-mono font-semibold text-amber-800">Step 02</p>
                <h2 className="text-2xl font-bold text-stone-900 mt-0.5">How many hens?</h2>
              </div>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-xs font-semibold text-stone-600 hover:text-stone-900 flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Change Plan</span>
              </button>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-xl bg-stone-50 border border-stone-200">
              <img
                src={getPlanImage(selectedPlan.imageKey)}
                alt={selectedPlan.name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-lg object-cover shrink-0"
              />
              <div>
                <p className="text-xs text-stone-500">Selected Plan:</p>
                <p className="text-base font-bold text-stone-900">{selectedPlan.name}</p>
                <p className="text-xs font-mono font-semibold text-amber-800 mt-0.5">
                  Price: PKR {selectedPlan.henPrice.toLocaleString()} per hen · {selectedPlan.dailyEggs} Egg/day
                </p>
              </div>
            </div>

            {/* Quantity Selector */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-2">
                Select Hen Quantity
              </label>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-12 h-12 rounded-xl border border-stone-300 hover:bg-stone-100 flex items-center justify-center text-stone-800 transition-colors cursor-pointer"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <div className="flex-1 h-12 rounded-xl border border-stone-300 bg-stone-50 flex items-center justify-center font-mono text-xl font-bold text-stone-900 tabular-nums">
                  {quantity} {quantity === 1 ? 'Hen' : 'Hens'}
                </div>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-12 h-12 rounded-xl border border-stone-300 hover:bg-stone-100 flex items-center justify-center text-stone-800 transition-colors cursor-pointer"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Quick Quantity Buttons */}
            <div>
              <p className="text-xs text-stone-500 mb-2">Quick quantity selection:</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { label: '1 Hen', val: 1 },
                  { label: '3 Hens', val: 3 },
                  { label: '5 Hens', val: 5 },
                  { label: '10 Hens', val: 10 },
                ].map((item) => (
                  <button
                    key={item.val}
                    type="button"
                    onClick={() => setQuantity(item.val)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold font-mono transition-colors cursor-pointer whitespace-nowrap ${
                      quantity === item.val
                        ? 'border-amber-700 bg-amber-700 text-white'
                        : 'border-stone-200 bg-white text-stone-800 hover:bg-stone-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setStep(3)}
              className="w-full py-3.5 px-6 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs tracking-wide uppercase transition-colors cursor-pointer"
            >
              CONTINUE TO PAYMENT
            </button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">
                Order Summary
              </p>
              <h3 className="text-xl font-bold text-stone-900 mb-5">Your hen investment</h3>

              <div className="space-y-3 text-xs border-t border-stone-200 pt-4">
                <div className="flex justify-between">
                  <span className="text-stone-500">Selected plan</span>
                  <span className="font-semibold text-stone-900">{selectedPlan.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Quantity × price</span>
                  <span className="font-mono font-semibold text-stone-900 tabular-nums">
                    {quantity} × PKR {selectedPlan.henPrice.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Plan subtotal</span>
                  <span className="font-mono font-semibold text-stone-900 tabular-nums">
                    PKR {subtotal.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Gateway fee</span>
                  <span className="font-mono font-semibold text-stone-900 tabular-nums">
                    PKR {gatewayFee}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Farm setup</span>
                  <span className="font-mono font-semibold text-emerald-800">FREE</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Expected Daily Harvest</span>
                  <span className="font-mono font-semibold text-emerald-800 tabular-nums">
                    {quantity * selectedPlan.dailyEggs} Eggs / Day ({selectedPlan.durationDays} Days)
                  </span>
                </div>
                <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline">
                  <span className="text-sm font-bold text-stone-900">TOTAL PAYMENT</span>
                  <span className="text-xl font-bold text-amber-800 font-mono tabular-nums">
                    PKR {totalPayment.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-1.5 text-xs text-stone-600">
              <div className="flex items-center gap-2 font-semibold text-stone-900">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Verification & Security Guarantees</span>
              </div>
              <p>· Secure payment request</p>
              <p>· Manual verification by Admin</p>
              <p>· Hens added after approval</p>
            </div>
          </div>
        </div>
      )}

      {/* STEP 03: SELECT PAYMENT METHOD & SUBMIT */}
      {step === 3 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-mono font-semibold text-amber-800">Step 03</p>
                <h2 className="text-2xl font-bold text-stone-900 mt-0.5">Select payment method</h2>
                <p className="text-xs text-stone-600 mt-1">
                  Choose a secure gateway to continue your hen deposit.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="text-xs font-semibold text-stone-600 hover:text-stone-900 flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Quantity</span>
              </button>
            </div>

            {/* Payment Options */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {(['Bank Account', 'JazzCash', 'EasyPaisa', 'SadaPay', 'UPaisa'] as PaymentGateway[]).map(
                (gw) => (
                  <button
                    key={gw}
                    type="button"
                    onClick={() => setSelectedGateway(gw)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                      selectedGateway === gw
                        ? 'border-amber-700 bg-amber-700 text-white'
                        : 'border-stone-200 bg-stone-50 text-stone-800 hover:bg-stone-100'
                    }`}
                  >
                    {gw}
                  </button>
                )
              )}
            </div>

            {/* Admin-Configured Gateway Details */}
            <div className="p-5 rounded-xl bg-stone-50 border border-stone-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  {selectedGateway} Receiving Account
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyAccount(currentGatewayInfo.number)}
                  className="flex items-center gap-1.5 text-xs font-semibold text-amber-800 hover:underline cursor-pointer"
                >
                  {copiedAccount ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAccount ? 'Copied' : 'Copy Number'}</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <p className="text-stone-500">Account Title</p>
                  <p className="font-bold text-stone-900 text-sm mt-0.5">{currentGatewayInfo.title}</p>
                </div>
                <div>
                  <p className="text-stone-500">Account / Wallet Number</p>
                  <p className="font-mono font-bold text-amber-800 text-sm mt-0.5">
                    {currentGatewayInfo.number}
                  </p>
                </div>
              </div>
              <p className="text-xs text-stone-600 font-mono">{currentGatewayInfo.extra}</p>
              <p className="text-xs text-stone-600 pt-2 border-t border-stone-200 leading-relaxed">
                {settings.paymentInstructions}
              </p>
            </div>

            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmitOrder} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Transaction / Reference ID (TID)
                </label>
                <input
                  type="text"
                  required
                  value={referenceId}
                  onChange={(e) => setReferenceId(e.target.value)}
                  placeholder="Enter your bank or wallet Trx / Reference ID"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm font-mono focus:outline-none focus:border-amber-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Payment Proof Details / Sender Account Number (Optional)
                </label>
                <textarea
                  rows={2}
                  value={proofNote}
                  onChange={(e) => setProofNote(e.target.value)}
                  placeholder="Enter sender mobile number, account title, or payment note for Admin verification"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-sm focus:outline-none focus:border-amber-700"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 px-6 rounded-xl bg-amber-700 hover:bg-amber-800 disabled:opacity-60 text-white font-semibold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                {submitting
                  ? 'Submitting Payment Request...'
                  : `Submit Hen Order (PKR ${totalPayment.toLocaleString()})`}
              </button>
            </form>
          </div>

          {/* Right Order Summary Recap */}
          <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 space-y-5 self-start">
            <h3 className="text-lg font-bold text-stone-900">Investment Recap</h3>
            <div className="space-y-2.5 text-xs border-t border-stone-200 pt-4">
              <div className="flex justify-between">
                <span className="text-stone-500">Package</span>
                <span className="font-semibold text-stone-900">{selectedPlan.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Hen Quantity</span>
                <span className="font-mono font-semibold text-stone-900">{quantity} Hens</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Daily Eggs</span>
                <span className="font-mono font-semibold text-emerald-800">
                  {quantity * selectedPlan.dailyEggs} Eggs / Day
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Selected Gateway</span>
                <span className="font-semibold text-stone-900">{selectedGateway}</span>
              </div>
              <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline">
                <span className="font-bold text-stone-900">TOTAL PAYMENT</span>
                <span className="text-lg font-bold text-amber-800 font-mono tabular-nums">
                  PKR {totalPayment.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
