/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  auth,
  db,
  handleFirestoreError,
  OperationType,
  OWNER_ADMIN_EMAIL,
} from './firebase';
import {
  DEFAULT_PLATFORM_SETTINGS,
  DepositRequest,
  EggBuyer,
  EggSale,
  FarmPlan,
  HenOrder,
  INITIAL_EGG_BUYERS,
  INITIAL_FARM_PLANS,
  PlatformSettings,
  TransactionRecord,
  UserAccount,
  UserPublic,
  WithdrawalRequest,
} from './types';
import { HomePage } from './components/HomePage';
import { AuthPages } from './components/AuthPages';
import { UserDashboard } from './components/UserDashboard';
import { AdminPanel } from './components/AdminPanel';

type ViewMode = 'home' | 'login' | 'register' | 'welcome' | 'dashboard' | 'admin';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('home');
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);

  // Live Firestore State
  const [plans, setPlans] = useState<FarmPlan[]>(INITIAL_FARM_PLANS);
  const [buyers, setBuyers] = useState<EggBuyer[]>(INITIAL_EGG_BUYERS);
  const [settings, setSettings] = useState<PlatformSettings>(DEFAULT_PLATFORM_SETTINGS);
  const [userAccount, setUserAccount] = useState<UserAccount | null>(null);
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [henOrders, setHenOrders] = useState<HenOrder[]>([]);
  const [eggSales, setEggSales] = useState<EggSale[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [teamMembers, setTeamMembers] = useState<UserPublic[]>([]);
  const [initialReferrer, setInitialReferrer] = useState<string>('');

  // Parse /signup?ref=username or ?ref=username on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refParam = params.get('ref');
    if (refParam) {
      setInitialReferrer(refParam.replace(/\s+/g, ''));
      setViewMode('register');
    } else if (window.location.pathname.includes('/signup')) {
      setViewMode('register');
    }
  }, []);

  // 1. Auth State Listener
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setAuthReady(true);
    });
    return () => unsubAuth();
  }, []);

  // Must match Firestore security rules isAdmin() check so non-admin users never trigger admin writes
  const isRuleVerifiedAdmin = Boolean(
    firebaseUser &&
      firebaseUser.email?.toLowerCase() === OWNER_ADMIN_EMAIL.toLowerCase() &&
      firebaseUser.emailVerified
  );

  const isOwnerAdmin = Boolean(isRuleVerifiedAdmin || userAccount?.role === 'admin');

  // 2. Public Real-Time Listeners: Plans, Buyers, Global Settings
  useEffect(() => {
    if (!authReady) return;

    const unsubPlans = onSnapshot(
      query(collection(db, 'plans'), where('active', 'in', [true, false])),
      (snap) => {
        if (!snap.empty) {
          const loadedPlans: FarmPlan[] = [];
          snap.forEach((d) => loadedPlans.push(d.data() as FarmPlan));
          loadedPlans.sort((a, b) => a.henPrice - b.henPrice);
          setPlans(loadedPlans);
        } else if (isRuleVerifiedAdmin) {
          INITIAL_FARM_PLANS.forEach((plan) => {
            setDoc(doc(db, 'plans', plan.id), plan).catch((err) =>
              handleFirestoreError(err, OperationType.WRITE, `plans/${plan.id}`)
            );
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'plans')
    );

    const unsubBuyers = onSnapshot(
      query(collection(db, 'buyers'), where('active', 'in', [true, false])),
      (snap) => {
        if (!snap.empty) {
          const loadedBuyers: EggBuyer[] = [];
          snap.forEach((d) => loadedBuyers.push(d.data() as EggBuyer));
          loadedBuyers.sort((a, b) => b.ratePerEgg - a.ratePerEgg);
          setBuyers(loadedBuyers);
        } else if (isRuleVerifiedAdmin) {
          INITIAL_EGG_BUYERS.forEach((buyer) => {
            setDoc(doc(db, 'buyers', buyer.id), buyer).catch((err) =>
              handleFirestoreError(err, OperationType.WRITE, `buyers/${buyer.id}`)
            );
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'buyers')
    );

    const unsubSettings = onSnapshot(
      doc(db, 'settings', 'global'),
      (snap) => {
        if (snap.exists()) {
          setSettings(snap.data() as PlatformSettings);
        } else if (isRuleVerifiedAdmin) {
          setDoc(doc(db, 'settings', 'global'), DEFAULT_PLATFORM_SETTINGS).catch((err) =>
            handleFirestoreError(err, OperationType.WRITE, 'settings/global')
          );
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'settings/global')
    );

    return () => {
      unsubPlans();
      unsubBuyers();
      unsubSettings();
    };
  }, [authReady, isRuleVerifiedAdmin]);

  // 3. Authenticated Farmer Real-Time Listeners
  useEffect(() => {
    if (!authReady || !firebaseUser) {
      setUserAccount(null);
      setDeposits([]);
      setHenOrders([]);
      setEggSales([]);
      setWithdrawals([]);
      setTransactions([]);
      setTeamMembers([]);
      return;
    }

    const uid = firebaseUser.uid;

    const unsubUser = onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        if (snap.exists()) {
          setUserAccount(snap.data() as UserAccount);
        } else {
          // Auto-provision user profile if signed in for the first time
          const now = new Date().toISOString();
          const email = firebaseUser.email || `farmer_${uid.slice(0, 6)}@eggsnava.digital`;
          const canAssignAdminRole =
            email.toLowerCase() === OWNER_ADMIN_EMAIL.toLowerCase() && firebaseUser.emailVerified;

          const fallbackUsername = (
            firebaseUser.displayName ||
            email.split('@')[0] ||
            `farmer_${uid.slice(0, 6)}`
          )
            .replace(/\s+/g, '')
            .replace(/[^a-zA-Z0-9_-]/g, '')
            .slice(0, 40);
          const safeUsername =
            fallbackUsername.length >= 3 ? fallbackUsername : `farmer_${uid.slice(0, 6)}`;
          const safeRef = (initialReferrer || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);

          const newAccount: UserAccount = {
            uid,
            username: safeUsername,
            phone: '03000000000',
            email: email.slice(0, 120),
            referralCode: safeUsername,
            referredBy: safeRef,
            role: canAssignAdminRole ? 'admin' : 'user',
            status: 'active',
            verifiedFarmer: true,
            availableBalance: 0,
            eggsBalance: 0,
            activeHens: 0,
            totalHens: 0,
            pendingHens: 0,
            pendingEggs: 0,
            totalEggsProfit: 0,
            referralBonus: 0,
            totalInvestment: 0,
            totalWithdraw: 0,
            totalReferrals: 0,
            activeTeam: 0,
            lastHarvestAt: '',
            createdAt: now,
            updatedAt: now,
          };

          const newPublic: UserPublic = {
            uid,
            username: safeUsername,
            referralCode: safeUsername,
            referredBy: safeRef,
            verifiedFarmer: true,
            status: 'active',
            createdAt: now,
          };

          setDoc(doc(db, 'users', uid), newAccount).catch((err) =>
            handleFirestoreError(err, OperationType.CREATE, `users/${uid}`)
          );
          setDoc(doc(db, 'users_public', uid), newPublic).catch((err) =>
            handleFirestoreError(err, OperationType.CREATE, `users_public/${uid}`)
          );
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
    );

    const qDeps = query(collection(db, 'deposits'), where('userId', '==', uid));
    const unsubDeps = onSnapshot(
      qDeps,
      (snap) => {
        const list: DepositRequest[] = [];
        snap.forEach((d) => list.push(d.data() as DepositRequest));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setDeposits(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'deposits')
    );

    const qHens = query(collection(db, 'hen_orders'), where('userId', '==', uid));
    const unsubHens = onSnapshot(
      qHens,
      (snap) => {
        const list: HenOrder[] = [];
        snap.forEach((d) => list.push(d.data() as HenOrder));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setHenOrders(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'hen_orders')
    );

    const qSales = query(collection(db, 'egg_sales'), where('userId', '==', uid));
    const unsubSales = onSnapshot(
      qSales,
      (snap) => {
        const list: EggSale[] = [];
        snap.forEach((d) => list.push(d.data() as EggSale));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setEggSales(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'egg_sales')
    );

    const qWds = query(collection(db, 'withdrawals'), where('userId', '==', uid));
    const unsubWds = onSnapshot(
      qWds,
      (snap) => {
        const list: WithdrawalRequest[] = [];
        snap.forEach((d) => list.push(d.data() as WithdrawalRequest));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setWithdrawals(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'withdrawals')
    );

    const qTxs = query(collection(db, 'transactions'), where('userId', '==', uid));
    const unsubTxs = onSnapshot(
      qTxs,
      (snap) => {
        const list: TransactionRecord[] = [];
        snap.forEach((d) => list.push(d.data() as TransactionRecord));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setTransactions(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'transactions')
    );

    return () => {
      unsubUser();
      unsubDeps();
      unsubHens();
      unsubSales();
      unsubWds();
      unsubTxs();
    };
  }, [authReady, firebaseUser, initialReferrer]);

  // 4. Listen for referred team members once userAccount.referralCode is known
  useEffect(() => {
    if (!authReady || !firebaseUser || !userAccount?.referralCode) return;

    const qTeam = query(
      collection(db, 'users_public'),
      where('referredBy', '==', userAccount.referralCode)
    );
    const unsubTeam = onSnapshot(
      qTeam,
      (snap) => {
        const list: UserPublic[] = [];
        snap.forEach((d) => list.push(d.data() as UserPublic));
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setTeamMembers(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users_public')
    );

    return () => unsubTeam();
  }, [authReady, firebaseUser, userAccount?.referralCode]);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#F9F8F6] flex items-center justify-center p-6">
        <div className="text-center space-y-2">
          <p className="text-lg font-bold text-stone-900 font-display">
            EGGS NAVA DIGITAL FARM
          </p>
          <p className="text-xs text-stone-500">Connecting to Firebase Poultry Ledger...</p>
        </div>
      </div>
    );
  }

  if (viewMode === 'login' || viewMode === 'register' || viewMode === 'welcome') {
    return (
      <AuthPages
        mode={viewMode}
        setMode={setViewMode}
        settings={settings}
        initialReferrer={initialReferrer}
        currentUserAccount={userAccount}
      />
    );
  }

  if (viewMode === 'admin' && isRuleVerifiedAdmin) {
    return (
      <AdminPanel
        plans={plans}
        buyers={buyers}
        settings={settings}
        onExitAdmin={() => setViewMode('dashboard')}
      />
    );
  }

  if (viewMode === 'dashboard' && firebaseUser && userAccount) {
    return (
      <UserDashboard
        userAccount={userAccount}
        plans={plans}
        buyers={buyers}
        settings={settings}
        deposits={deposits}
        henOrders={henOrders}
        eggSales={eggSales}
        withdrawals={withdrawals}
        transactions={transactions}
        teamMembers={teamMembers}
        isAdmin={isRuleVerifiedAdmin}
        onNavigateApp={setViewMode}
      />
    );
  }

  return (
    <HomePage
      onNavigate={setViewMode}
      plans={plans}
      settings={settings}
      isAuthenticated={Boolean(firebaseUser && userAccount)}
      isAdmin={isRuleVerifiedAdmin}
    />
  );
}
