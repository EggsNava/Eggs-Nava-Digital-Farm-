export interface UserPublic {
  uid: string;
  username: string;
  referralCode: string;
  referredBy: string;
  verifiedFarmer: boolean;
  status: 'active' | 'deactivated';
  createdAt: string;
}

export interface UserAccount {
  uid: string;
  username: string;
  phone: string;
  email: string;
  referralCode: string;
  referredBy: string;
  role: 'user' | 'admin';
  status: 'active' | 'deactivated';
  verifiedFarmer: boolean;
  availableBalance: number;
  eggsBalance: number;
  activeHens: number;
  totalHens: number;
  pendingHens: number;
  pendingEggs: number;
  totalEggsProfit: number;
  referralBonus: number;
  totalInvestment: number;
  totalWithdraw: number;
  totalReferrals: number;
  activeTeam: number;
  lastHarvestAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface FarmPlan {
  id: string;
  name: string;
  description: string;
  henPrice: number;
  dailyEggs: number;
  referReward: number;
  durationDays: number;
  active: boolean;
  imageKey: string;
  updatedAt: string;
}

export interface EggBuyer {
  id: string;
  name: string;
  rating: number;
  tradesCount: number;
  ratePerEgg: number;
  successRate: number;
  minQty: number;
  maxQty: number;
  active: boolean;
  updatedAt: string;
}

export interface PlatformSettings {
  whatsappAdmin: string;
  whatsappOwner: string;
  whatsappGroup: string;
  whatsappChannel: string;
  bankName: string;
  bankAccountTitle: string;
  bankAccountNumber: string;
  bankIban: string;
  jazzCashTitle: string;
  jazzCashNumber: string;
  easyPaisaTitle: string;
  easyPaisaNumber: string;
  sadaPayTitle: string;
  sadaPayNumber: string;
  uPaisaTitle: string;
  uPaisaNumber: string;
  paymentInstructions: string;
  depositInstructions: string;
  withdrawalInstructions: string;
  defaultReferReward: number;
  referralRules: string;
  referralEnabled: boolean;
  fbrSecpEnabled: boolean;
  fbrRegistrationInfo: string;
  secpRegistrationInfo: string;
  appDownloadUrl: string;
  rewardsInfo: string;
  rewardPrizesInfo: string;
  communityFarmersCount: string;
  dailyHarvestRateInfo: string;
  updatedAt: string;
}

export interface DepositRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  paymentMethod: string;
  referenceId: string;
  proofNote: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  updatedAt: string;
}

export interface HenOrder {
  id: string;
  userId: string;
  username: string;
  planId: string;
  planName: string;
  henPrice: number;
  quantity: number;
  dailyEggsPerHen: number;
  totalDailyEggs: number;
  durationDays: number;
  referReward: number;
  totalAmount: number;
  paymentMethod: string;
  referenceId: string;
  proofNote: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  startDate: string;
  endDate: string;
  lastHarvestDate: string;
  eggsAccumulated: number;
  createdAt: string;
  updatedAt: string;
}

export interface EggSale {
  id: string;
  userId: string;
  username: string;
  buyerId: string;
  buyerName: string;
  eggQuantity: number;
  ratePerEgg: number;
  totalPayout: number;
  payoutMethod: string;
  payoutAccountDetails: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  updatedAt: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  payoutMethod: string;
  accountDetails: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  updatedAt: string;
}

export interface TransactionRecord {
  id: string;
  userId: string;
  username: string;
  type: 'Deposit' | 'Hen Purchase' | 'Egg Sale' | 'Withdrawal' | 'Referral Reward' | 'Egg Profit' | 'Admin Adjustment';
  amount: number;
  unit: 'PKR' | 'EGGS' | 'HENS';
  status: 'Pending' | 'Approved' | 'Rejected';
  referenceId: string;
  description: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  targetUserId: string;
  targetUsername: string;
  adjustmentType: string;
  deltaAmount: number;
  reason: string;
  adminEmail: string;
  createdAt: string;
}

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettings = {
  whatsappAdmin: 'https://wa.me/923000000000',
  whatsappOwner: 'https://wa.me/923000000000',
  whatsappGroup: 'https://chat.whatsapp.com/',
  whatsappChannel: 'https://whatsapp.com/channel/',
  bankName: 'Meezan Bank / Allied Bank (Configure in Admin)',
  bankAccountTitle: 'EGGS NAVA DIGITAL FARM',
  bankAccountNumber: 'Pending Admin Configuration',
  bankIban: 'PK00MEZN0000000000000000',
  jazzCashTitle: 'EGGS NAVA DIGITAL FARM',
  jazzCashNumber: 'Pending Admin Configuration',
  easyPaisaTitle: 'EGGS NAVA DIGITAL FARM',
  easyPaisaNumber: 'Pending Admin Configuration',
  sadaPayTitle: 'EGGS NAVA DIGITAL FARM',
  sadaPayNumber: 'Pending Admin Configuration',
  uPaisaTitle: 'EGGS NAVA DIGITAL FARM',
  uPaisaNumber: 'Pending Admin Configuration',
  paymentInstructions: 'Transfer the exact amount to the selected gateway account and enter your Transaction / Reference ID below. Manual verification takes place before hens or balance are credited.',
  depositInstructions: 'Send deposit amount to any active payment gateway below, then enter your Trx/Reference ID. Funds are added to Available Balance upon Admin verification.',
  withdrawalInstructions: 'Enter your withdrawal amount and valid JazzCash, EasyPaisa, SadaPay, UPaisa, or Bank Account details. Withdrawals are processed after Admin verification.',
  defaultReferReward: 120,
  referralRules: 'Share your personal referral link with fellow farmers. When your referred member purchases a hen package and it is approved by Admin, you earn the configured referral reward in PKR.',
  referralEnabled: true,
  fbrSecpEnabled: false,
  fbrRegistrationInfo: '',
  secpRegistrationInfo: '',
  appDownloadUrl: '',
  rewardsInfo: 'Active farmers who maintain a healthy flock of 25+ hens qualify for monthly feed & harvest performance bonuses configured by Admin.',
  rewardPrizesInfo: 'Top community team builders and consistent egg harvesters receive seasonal farm equipment and cash prizes announced on our official WhatsApp Channel.',
  communityFarmersCount: 'Verified Community Network',
  dailyHarvestRateInfo: '24-Hour Natural Cycle',
  updatedAt: new Date().toISOString()
};

export const INITIAL_FARM_PLANS: FarmPlan[] = [
  {
    id: 'golden_hen',
    name: 'Golden Hen',
    description: 'Naturally raised Rhode Island Red laying hen with consistent daily brown egg production and full pasture care.',
    henPrice: 500,
    dailyEggs: 1,
    referReward: 120,
    durationDays: 120,
    active: true,
    imageKey: 'hen',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pasture_flock_bundle',
    name: 'Pasture Flock Starter',
    description: 'High-yield organic brown layer package designed for growing digital poultry farms with daily harvest tracking.',
    henPrice: 1000,
    dailyEggs: 2,
    referReward: 240,
    durationDays: 120,
    active: true,
    imageKey: 'pasture',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'heritage_layer_pro',
    name: 'Heritage Commercial Layer',
    description: 'Commercial-grade free-range brown hen package with priority market buyer rates and dedicated farm management.',
    henPrice: 2500,
    dailyEggs: 5,
    referReward: 500,
    durationDays: 120,
    active: true,
    imageKey: 'eggs',
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_EGG_BUYERS: EggBuyer[] = [
  {
    id: 'buyer_al_noor_traders',
    name: 'Al-Noor Organic Wholesale',
    rating: 4.9,
    tradesCount: 412,
    ratePerEgg: 28,
    successRate: 99.2,
    minQty: 5,
    maxQty: 5000,
    active: true,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'buyer_green_valley_mart',
    name: 'Green Valley Farm Mart',
    rating: 4.8,
    tradesCount: 289,
    ratePerEgg: 27,
    successRate: 98.5,
    minQty: 1,
    maxQty: 2000,
    active: true,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'buyer_punjab_egg_depot',
    name: 'Punjab Fresh Egg Depot',
    rating: 4.95,
    tradesCount: 640,
    ratePerEgg: 30,
    successRate: 99.6,
    minQty: 20,
    maxQty: 10000,
    active: true,
    updatedAt: new Date().toISOString()
  }
];
